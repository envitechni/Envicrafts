from django.urls import path
from . import views

urlpatterns = [
    path('', views.remotedevices, name="remoteit-devices"),
   
]
