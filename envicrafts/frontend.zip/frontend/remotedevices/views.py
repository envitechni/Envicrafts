from django.shortcuts import render
import requests
from requests_http_signature import HTTPSignatureAuth
from base64 import b64decode
from django.conf import settings
import time
# Create your views here.

### Please install below library
### pip install requests_http_signature==v0.1.0


def remotedevices(request):
    key_id = 'QTQCMRQYC3AOKHBTZNV6'
    key_secret_id = 'EzxPjWbOhcqFalQ+OfuVddxGR/2gtf3ZKOBUOjzy'
    api_key = 'MTYyQUVFRTEtOUI4Ny00OUNBLUJCMkItRjU5QkJDMjY0RTE4'

    body = ''  #update this with your data if posting with a body
    host = 'api.remote.it'
    url_path = '/apv/v27/device/list/all'
    content_type_header = 'application/json'
    content_length_header = str(len(body))
    headers = {
        'host': host,
        'content-type': content_type_header,
        'content-length': content_length_header,
        'DeveloperKey': api_key
    }
    response = requests.get('https://' + host + url_path,
                            auth=HTTPSignatureAuth(algorithm="hmac-sha256",
                                                key=b64decode(key_secret_id),
                                                key_id=key_id,
                                                headers=[
                                                    '(request-target)', 'host',
                                                    'date', 'content-type',
                                                    'content-length'
                                                ]),
                            headers=headers)

    ip = settings.IP
    headers1 = settings.HEADERS
    url = ip+"/api/send-mail/"
    response1 = requests.request('GET',url,headers=headers1)

    return render(request, 'pages/remoteit-devices.html',{'devices':response.json()['devices']})
