from django.apps import AppConfig


class AuditlogsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'auditlogs'
