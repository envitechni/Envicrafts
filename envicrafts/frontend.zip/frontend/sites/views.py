from django.shortcuts import render
from django.http.response import JsonResponse
from django.conf import settings
from django.contrib import messages
from itertools import zip_longest
from globalData.decorator import login_required
from django.http import StreamingHttpResponse

import requests
import threading
import queue as Queue
import json, xmltodict
# Create your views here.
@login_required
def sites(request):
    ip = settings.IP
    headers = settings.HEADERS
    url = ip+"/setup/category/"
    response = requests.request('GET',url,headers=headers)
    
    realtime_site_url = ip+f"/parameters/realtime-sites/?id={request.session['site']}"
    realtime_response =  requests.request('GET',realtime_site_url,headers=headers)
    if request.method == "POST":
        category = request.POST.get('category')
        status = request.POST.get('status')
        params = {
            'category': category,
            'status': status,
        }
        realtime_site=requests.request("GET", realtime_site_url, headers=headers,params=params)
        
        selected_data = {
            'category': category,
            'status': status
        }
        return render(request, 'pages/sites-status.html',{'categories':response.json(), 'realtime_response':realtime_site.json(),
        'selected_data': selected_data})
    
    return render(request, 'pages/sites-status.html',{'categories':response.json(), 'realtime_response':realtime_response.json()})

@login_required
def camera(request):
    ip = settings.IP
    headers = settings.HEADERS
    url = ip+"/setup/category/"
    response = requests.request('GET',url,headers=headers)
    camera_detail_url = ip+f"/sites/camera?site={request.session['site']}"
    camera_response = requests.request('GET',camera_detail_url,headers=headers)
    if request.method == "POST":
        category = request.POST.get('category')
        site = request.POST.get('site')
        status = request.POST.get('status')
        params = {
            'category': category,
            'site':site,
            'status': status,
        }
        realtime_camera=requests.request("GET", camera_detail_url, headers=headers,params=params)
        
        return render(request, 'pages/camera-status.html',{'categories':response.json(), 'cameras':realtime_camera.json(), 
        'selected_data': params})
    else:   
        return render(request, 'pages/camera-status.html',{'categories':response.json(), 'cameras':camera_response.json(),})

def sites_status(url,headers,queue,):
    inactive_data = requests.request("GET", url, headers=headers)
    inactive_sites = [value for key, value in inactive_data.json()['data'].items()]
    queue.put(inactive_sites)

@login_required
def category(request):
    queue = Queue.Queue()
    ip = settings.IP
    headers = settings.HEADERS
    url = ip+"/setup/category/"
    response = requests.request('GET',url,headers=headers)
    categories = []    
    active_data = []
    
    active_url = ip+"/sites/site-categorywise-count?status=Active"
    deactive_url = ip+"/sites/site-categorywise-count?status=Inactive"
    delayed_url = ip+"/sites/site-categorywise-count?status=Delayed"
    
    active_count = requests.request("GET", active_url, headers=headers)
    
    for key, value in active_count.json()['data'].items():
        categories.append(key)
        active_data.append(value)

    thread1 =  threading.Thread(target=sites_status,name="thread1",args=[deactive_url,headers,queue,])
    thread2 =  threading.Thread(target=sites_status,name="thread2",args=[delayed_url,headers,queue,])
    thread1.start()
    thread2.start()

    thread1.join()
    thread2.join()
    inactive_data = queue.get()
    delayed_data = queue.get()
    
    final_data = {}
    for row in zip_longest(categories,active_data,inactive_data,delayed_data):
        final_data[row[0]] = row[1:]

    if request.method == "POST":
        category = request.POST.get('category')
        new_dict = {}
        for key,value in final_data.items():
            if key == category:
                new_dict[key] = value
       
        return render(request, 'pages/category-status.html',{'categories':response.json(),'final_data':new_dict, 
        'category': category})

    return render(request, 'pages/category-status.html',{'categories':response.json(),'final_data':final_data})

@login_required
def map(request):
    ip = settings.IP
    headers = settings.HEADERS
    url = ip+"/setup/category/"
    response = requests.request('GET',url,headers=headers)
    site_url = ip+"/sites/"
    site_response = requests.request('GET',site_url,headers=headers)
    if request.method == "POST":
        category = request.POST.get('category')
        status = request.POST.get('status')
        params = {
            'category':category,
            'status':status
        }
        map_response = requests.request('GET',site_url,headers=headers,params=params)
        return render(request, 'pages/map-view.html',{'categories':response.json(), 'sites':map_response.json(),
        'selected_data': params})

    return render(request, 'pages/map-view.html',{'categories':response.json(), 'sites':site_response.json()})

@login_required
def realtimedata(request):
    ip = settings.IP
    headers = settings.HEADERS
    url = ip+"/parameters/realtime-values/"
    id = request.GET['id']
    params = {
        'site':id
    }
    realtime_response = requests.request('GET',url,headers=headers,params=params)
    realtime_site_url = ip+"/parameters/realtime-sites/"
    site_params = {'id':id}
    realtime_site=requests.request("GET", realtime_site_url, headers=headers,params=site_params)
    print(realtime_site)

    return render(request, 'pages/realtime-data.html',{'realtime_data':realtime_response.json(), 'site_data': realtime_site.json()['data']})

@login_required
def livecamera(request):
    ip = settings.IP
    headers = settings.HEADERS
    camera_url=ip+"/sites/camera"
    id = request.GET['id']
    params = {
        'id':id
    }
    camera_details = requests.request("GET", camera_url, headers=headers,params=params)
    return render(request, 'pages/live-camera.html',{'camera_details':camera_details.json()['data']})

@login_required
def historyview(request):
    ip = settings.IP
    headers = settings.HEADERS
    camera_url=ip+"/sites/camera"
    id = request.GET['id']
    params = {
        'id':id
    }
    camera_details = requests.request("GET", camera_url, headers=headers,params=params)
    return render(request, 'pages/history-view.html',{'camera_details':camera_details.json()['data'],})

@login_required
def ptzControl(request):
    ip = settings.IP
    headers = settings.HEADERS
    try:
        id = request.GET['id']
    except: 
        pass

    camera_url = ip+"/sites/camera"
    params = {
        'id': id,
    }
    cameras = requests.request("GET", camera_url, headers=headers, params=params)
    camera_data = cameras.json()['data']
    print(camera_data)
    ip_addr = camera_data[0]['ip']
    username = camera_data[0]['username']
    password = camera_data[0]['password']
    channel_id = camera_data[0]['channel']

    capabilities_url = "http://"+username+":"+password+"@"+ip_addr+"/PTZCtrl/channels/"+str(channel_id)
    capabilities = requests.request('GET', capabilities_url)
    dict_capabilities = xmltodict.parse(capabilities.text)
    dict_capabilities = json.dumps(dict_capabilities)
    dict_capabilities = json.loads(dict_capabilities)
    p_range = dict_capabilities['PTZChannel']['AbsolutePanTiltPositionSpace']['XRange']
    t_range = dict_capabilities['PTZChannel']['AbsolutePanTiltPositionSpace']['YRange']
    z_range = dict_capabilities['PTZChannel']['AbsoluteZoomPositionSpace']['ZRange']

    position_url = "http://"+username+":"+password+"@"+ip_addr+"/PTZCtrl/channels/"+str(channel_id)+"/status"
    position = requests.request('GET', position_url)
    dict_position = xmltodict.parse(position.text)
    dict_position = json.dumps(dict_position)
    dict_position = json.loads(dict_position)
    coordinates = dict_position['PTZStatus']['AbsoluteHigh']

    X_MIN = int(p_range['Min'])
    X_MAX = int(p_range['Max'])
    Y_MIN = int(t_range['Min'])
    Y_MAX = int(t_range['Max'])
    Z_MIN = int(z_range['Min'])
    Z_MAX = int(z_range['Max'])
    P_POS = int(coordinates['azimuth'])
    T_POS = int(coordinates['elevation'])
    Z_POS = int(coordinates['absoluteZoom'])

    control = request.GET['control']
    if control == "zoom-in":
        if Z_POS < Z_MAX:
            new_zoom = Z_POS+10
            zoom_url = "http://"+username+":"+password+"@"+ip_addr+"/PTZCtrl/channels/"+str(channel_id)+"/Absolute"
            zoom_data = "<PTZData>\r\n    <AbsoluteHigh>\r\n        <azimuth>"+str(P_POS)+"</azimuth>\r\n        <elevation>"+str(T_POS)+"</elevation>\r\n        <absoluteZoom>"+str(new_zoom)+"</absoluteZoom>\r\n    </AbsoluteHigh>\r\n</PTZData>"
            zoom_response = requests.request("PUT", zoom_url, data=zoom_data)
    elif control == "zoom-out":
        if Z_POS > Z_MIN:
            new_zoom = Z_POS-10
            zoom_url = "http://"+username+":"+password+"@"+ip_addr+"/PTZCtrl/channels/"+str(channel_id)+"/Absolute"
            zoom_data = "<PTZData>\r\n    <AbsoluteHigh>\r\n        <azimuth>"+str(P_POS)+"</azimuth>\r\n        <elevation>"+str(T_POS)+"</elevation>\r\n        <absoluteZoom>"+str(new_zoom)+"</absoluteZoom>\r\n    </AbsoluteHigh>\r\n</PTZData>"
            zoom_response = requests.request("PUT", zoom_url, data=zoom_data)
    elif control == "move-up":
        if T_POS > Y_MIN:
            new_pos = T_POS-100
            pos_url = "http://"+username+":"+password+"@"+ip_addr+"/PTZCtrl/channels/"+str(channel_id)+"/Absolute"
            pos_data = "<PTZData>\r\n    <AbsoluteHigh>\r\n        <azimuth>"+str(P_POS)+"</azimuth>\r\n        <elevation>"+str(new_pos)+"</elevation>\r\n        <absoluteZoom>"+str(Z_POS)+"</absoluteZoom>\r\n    </AbsoluteHigh>\r\n</PTZData>"
            pos_response = requests.request("PUT", pos_url, data=pos_data)
    elif control == "move-down":
        if T_POS < Y_MAX:
            new_pos = T_POS+100
            pos_url = "http://"+username+":"+password+"@"+ip_addr+"/PTZCtrl/channels/"+str(channel_id)+"/Absolute"
            pos_data = "<PTZData>\r\n    <AbsoluteHigh>\r\n        <azimuth>"+str(P_POS)+"</azimuth>\r\n        <elevation>"+str(new_pos)+"</elevation>\r\n        <absoluteZoom>"+str(Z_POS)+"</absoluteZoom>\r\n    </AbsoluteHigh>\r\n</PTZData>"
            pos_response = requests.request("PUT", pos_url, data=pos_data)
    elif control == "move-left":
        if P_POS > X_MIN:
            new_pos = P_POS-100
            pos_url = "http://"+username+":"+password+"@"+ip_addr+"/PTZCtrl/channels/"+str(channel_id)+"/Absolute"
            pos_data = "<PTZData>\r\n    <AbsoluteHigh>\r\n        <azimuth>"+str(new_pos)+"</azimuth>\r\n        <elevation>"+str(T_POS)+"</elevation>\r\n        <absoluteZoom>"+str(Z_POS)+"</absoluteZoom>\r\n    </AbsoluteHigh>\r\n</PTZData>"
            pos_response = requests.request("PUT", pos_url, data=pos_data)
    elif control == "move-right":
        if P_POS < X_MAX:
            new_pos = P_POS+100
            pos_url = "http://"+username+":"+password+"@"+ip_addr+"/PTZCtrl/channels/"+str(channel_id)+"/Absolute"
            pos_data = "<PTZData>\r\n    <AbsoluteHigh>\r\n        <azimuth>"+str(new_pos)+"</azimuth>\r\n        <elevation>"+str(T_POS)+"</elevation>\r\n        <absoluteZoom>"+str(Z_POS)+"</absoluteZoom>\r\n    </AbsoluteHigh>\r\n</PTZData>"
            pos_response = requests.request("PUT", pos_url, data=pos_data)

    data = {
        'message': control
    }
    return JsonResponse(data, safe=False)

@login_required
def getSites(request):
    ip = settings.IP
    category = request.GET['id']
    headers = settings.HEADERS
    params = {
        "category": category,
    }
    url = ip+f"/sites/?id={request.session['site']}"
    sites = requests.request("GET", url, headers=headers, params=params)
    return JsonResponse(sites.json(), safe=False)
