from django.urls import path
from . import views

urlpatterns = [
    path('', views.sites, name="sites-status"),
    path('camera', views.camera, name="camera-status"),
    path('category', views.category, name="category-status"),
    path('map-view', views.map, name="map-view"),
    path('realtime-data', views.realtimedata, name="realtime-data"),
    path('live-camera', views.livecamera, name="live-camera"),
    path('history-view', views.historyview, name="history-view"),
    path('get-sites/', views.getSites, name="get-sites"),
    path('ptz-control/', views.ptzControl, name="ptz-control"),
]
