"""frontend URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""

from django.contrib import admin
from django.urls import path, include
from django.conf.urls import (handler400, handler403, handler404, handler500)

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('home.urls')),
    path('sites/', include('sites.urls')),
    path('stations/', include('stations.urls')),
    path('reports/', include('reports.urls')),
    path('audit-logs/', include('auditlogs.urls')),
    path('users/', include('users.urls')),
    path('notifications/', include('notifications.urls')),
    path('calibration/', include('calibration.urls')),
    path('logs/', include('logs.urls')),
    path('analytics/', include('analytics.urls')),
    path('remotedevices/', include('remotedevices.urls')),
    path('wimen/', include('wimen.urls')),

]
handler400 = 'home.views.bad_request'
handler403 = 'home.views.page_forbidden'
handler404 = 'home.views.page_not_found'
handler500 = 'home.views.internal_server_error'