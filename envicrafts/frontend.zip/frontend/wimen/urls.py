from django.urls import path
from . import views

urlpatterns = [

    path('wimen/',views.wimendata,name='postdatawimen'),
    path('wimenfilter/',views.wimenfilter,name='wimenfilter'),
    
]
