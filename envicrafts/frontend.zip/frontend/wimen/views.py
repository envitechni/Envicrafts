from genericpath import exists
from django.shortcuts import render,redirect
import requests
import json
from django.conf import settings
import random
from itertools import count
# Create your views here.



def wimendata(request):
    global num,y
    ip = settings.IP
    headers = settings.HEADERS
    url = ip+"/wimen/wiman/list/"
    response = requests.request("GET", url, headers=headers)
    num = response.json()
    for x in num:
        y = x['serial_number']
    z = int(y)
    
    num = z
    def number():
        global num
        num += 1
        return num

    if request.method == 'POST':
      
        serial_number =number()
        # print(serial_number)
        date = request.POST['date']
        site_name = request.POST['site_name']
        device_number = request.POST['device_number']
        network_protocol = request.POST['network_protocol']
        mobile = request.POST['mobile']
        IMEI_No = request.POST['IMEI_No']
        configuration = request.POST.getlist('configuration')
        wiman_model = request.POST['wiman_model']
        sno = request.POST['sno']
        mfg = request.POST['mfg']
        mqtt = request.POST['mqtt']
        username = request.POST['username']
        password = request.POST['password']
        site_category = request.POST['site_category']

        z=', '.join(configuration)

        payload = json.dumps({
            "serial_number": serial_number,
            "date":  date,
            "site_name": site_name,
            "network_protocol": network_protocol,
            "mobile": mobile,
            "IMEI_No": IMEI_No,
            "configuration": z,
            "wiman_model": wiman_model,
            "sno": sno,
            "mfg": mfg,
            "mqtt": mqtt,
            "username": username,
            "password": password,
            "site_category": site_category,
            "device_number": device_number
        })
     
        ip = settings.IP
        headers = settings.HEADERS
        url = ip+"/wimen/wiman/create/"

        response = requests.request("POST", url, headers=headers, data=payload)    
        return redirect('wimenfilter')
       
        # return render(request,'pages/wimen.html')
    return render(request,'pages/wimen.html')    


def wimenfilter(request):
    
    ip = settings.IP
    headers = settings.HEADERS
    url = ip+"/wimen/wiman/list/"
    response = requests.request("GET", url, headers=headers)
    demo = response.json()
    
    
    return render(request,'pages/wimenfilter.html',{'response':demo})    