import datetime
import queue as Queue
from django.shortcuts import render, redirect
from django.conf import settings
from globalData.decorator import login_required
import requests
import json
from django.contrib import messages
import threading
from django.core.mail import send_mail
from django.template.loader import render_to_string
from django.views.decorators.csrf import csrf_exempt
import random

# Create your views here.
def site_count(url,headers,queue,):
    site_statuswise_count = requests.request("GET", url, headers=headers)
    site_status_data = [value for key, value in site_statuswise_count.json()['data'].items()]
    queue.put(site_status_data)

def pie_chart_data(url,headers,queue):
    categorywise_site_res = requests.request('GET',url,headers=headers)
    categorywise = [{key: value} for key, value in categorywise_site_res.json()['data'].items()]
    queue.put(categorywise)

def bar_chart_data(url,headers,queue):
    bar_chart_data = requests.request('GET',url,headers=headers)
    bar_ch_data = bar_chart_data.json()['data']
    active_list = []
    for values in bar_ch_data:
        active_list.append(values['Active'])

    inactive_list = []
    for values in bar_ch_data:
        inactive_list.append(values['Inactive'])

    delay_list = []
    for values in bar_ch_data:
        delay_list.append(values['delay'])

    final_data_dict = {
        "series": {
            "Active": active_list,
            "Inactive": inactive_list,
            "Delayed": delay_list,
        }
    }
    queue.put(final_data_dict)

def getAverageData(fromDate, toDate, site, station, interval, parameter_str, queue):
    ip = settings.IP
    headers = settings.HEADERS
    data_url = ip+f"/data/average?from={fromDate}&to={toDate}&site={site}&station={station}&interval={interval}"+parameter_str
    data_response = (requests.request('GET', data_url, headers=headers))
    queue.put(data_response.json())

def getTimestamp(fromDate, toDate, interval, queue):
    timestamp = []
    fromDate = datetime.datetime.strptime(fromDate+" 00:00:00", "%Y-%m-%d %H:%M:%S")
    toDate = datetime.datetime.strptime(toDate+" 23:59:00", "%Y-%m-%d %H:%M:%S")
    date_time = fromDate
    time_delta = int(interval)
    while date_time < toDate:
        date_time += datetime.timedelta(minutes=time_delta)
        timestamp.append(datetime.datetime.strftime(date_time, "%Y-%m-%d %H:%M:%S"))
    queue.put(timestamp)

class Send_Email(threading.Thread):
    def __init__(self,otp, email):
        threading.Thread.__init__(self)
        self.otp = otp
        self.email = email

    def run(self):
        subject = "OTP for Login into Envicrafts Platform"
        msg_html=render_to_string('pages/otp_msg.html',{'otp':self.otp})
        email_from = settings.EMAIL_HOST_USER
        recipient_list = [self.email,]
        send_mail(subject,from_email=email_from, message="OTP for Mail", recipient_list=recipient_list, html_message=msg_html)

class send_Email_CPCB(threading.Thread):
    def __init__(self, otp, email_id, ip_address, purpose):
        threading.Thread.__init__(self)
        self.timestamp = datetime.datetime.today()
        self.timestamp = datetime.datetime.strftime(self.timestamp, "%d-%m-%Y %H:%M")
        self.otp = otp
        self.email_id = email_id
        self.ip_address = ip_address
        self.purpose = purpose
    
    def run(self):
        subject = "User Activity on EnviCrafts Platform"
        email_from = settings.EMAIL_HOST_USER
        recipient_list = ['namitatare@technicrafts.in',]
        html_msg = render_to_string('pages/send_email_cpcb.html', {'timestamp': self.timestamp, 'email': self.email_id, 'otp': self.otp, 'ip': self.ip_address, 'purpose': self.purpose})

        send_mail(subject=subject, message="User Activity", from_email=email_from, recipient_list=recipient_list, html_message=html_msg)

def login(request):
    if request.method == "POST":
        username = request.POST.get('username')
        password = request.POST.get('password')
        ip=settings.IP
        headers = settings.HEADERS
        login_url = ip+"/users/login/"
        payload = json.dumps({
            "username":username,
            "password":password
        })
        response = requests.request("POST", login_url, headers=headers, data=payload)
        status=response.json()['status']
        if status == "success":
            data = response.json()['data']
            if data['is_staff'] == True:
                if data['authority'] == 3:
                    request.session['data'] = data
                    generated_otp = random.randint(100000, 999999)
                    request.session['otp'] = generated_otp
                    s1 = Send_Email(generated_otp, data['email'])
                    s1.start()
                    return redirect(otp)
                else:
                    request.session['id'] = data['id']
                    request.session['username'] = data['username']
                    request.session['name'] = data['displayName']
                    request.session['role'] = data['role']
                    request.session['mobile'] = data['mobile']
                    request.session['email'] = data['email']
                    request.session['site'] = ""
                    request.session['label'] = ""
                    request.session['site_name'] = ""
                    request.session['category'] = ""
            else:
                request.session['id'] = data['id']
                request.session['username'] = data['username']
                request.session['name'] = data['displayName']
                request.session['role'] = data['role']
                request.session['mobile'] = data['mobile']
                request.session['email'] = data['email']
                request.session['site'] = data['site']
                request.session['label'] = data['label']
                request.session['site_name'] = data['site_name']
                request.session['category'] = data['category']

            request.session['is_staff'] = data['is_staff']
            request.session['is_superuser'] = data['is_superuser']

            meta_data = request.META.get('HTTP_X_FORWARDED_FOR')
            if meta_data:
                audit_ip = meta_data.split(',')[-1].strip()
            else:
                audit_ip = request.META.get('REMOTE_ADDR')
            
            audit_url= ip + "/audit-logs/create/"
            timestamp=str(datetime.datetime.now())
            payload=json.dumps({
                "timestamp": timestamp,
                "username": username,
                "action_type": "Create",
                "action": "User log in at "+timestamp,
                "ip_address": audit_ip
                })
            audit_response=requests.request('POST',audit_url,headers=headers,data=payload)
            return redirect(summary)
        else: 
            messages.warning(request, "Please enter the correct username and password!")
    return render(request, 'pages/login.html')

@login_required
def home(request):
    if 'username' in request.session:
        queue = Queue.Queue()
        ip=settings.IP
        headers = settings.HEADERS
        site_count_url = ip+"/sites/site-statuswise-count/"
        station_count_url = ip+"/stations/station-count"
        categorywise_site_url = ip+"/sites/site-categorywise-count/" 
        statewise_site_url = ip+"/sites/site-statewise-count/"
        sites_status_url = ip+"/sites/site-status/"
        realtime_site_url = ip+"/parameters/realtime-sites/"
        realtime_response =  requests.request('GET',realtime_site_url,headers=headers)
    
        total_parameter_url = ip+"/parameters/total-parameters"  
        parameter_response = requests.request('GET',total_parameter_url,headers=headers)

        sites_status_res = requests.request('GET',sites_status_url,headers=headers)
        site_status_data = sites_status_res.json()['data']
        date_list = []
        for values in site_status_data:
            date_list.append(values['Date'])

        thread1 =  threading.Thread(
            target=site_count,
            name="thread1",
            args=[site_count_url,headers,queue,]
        )
        thread2 = threading.Thread(
            target=site_count,
            name="thread1",
            args=[station_count_url,headers,queue,]
        )
        thread3 = threading.Thread(
            target=pie_chart_data,
            name="thread3",
            args=[categorywise_site_url,headers,queue,]
        )
        thread4 = threading.Thread(
            target=pie_chart_data,
            name="thread4",
            args=[statewise_site_url,headers,queue,]
        )
        thread5 = threading.Thread(
            target=bar_chart_data,
            name="thread5",
            args=[sites_status_url,headers,queue,]
        )

        thread1.start()
        thread1.join()
        total_sites_by_status = queue.get()
        total_sites = sum(total_sites_by_status)
        
        thread2.start()
        thread2.join()
        total_stations_by_type = queue.get()
        total_stations = sum(total_stations_by_type)

        thread3.start()
        thread3.join()
        chart_data = queue.get()
        chart_data_label = []
        chart_data_series = []
        for values in chart_data:
            for key, value in values.items():
                chart_data_label.append(key)
                chart_data_series.append(value)

        thread4.start()
        thread4.join()
        state_chart_data = queue.get()
        state_chart_label = []
        state_chart_series = []
        for values in state_chart_data:
            for key, value in values.items():
                state_chart_label.append(key)
                state_chart_series.append(value)

        thread5.start()
        thread5.join()
        state_chart_data = queue.get()
        
        print(request.user.is_authenticated)
        return render(request, 'pages/home.html',{'site_status_data': total_sites_by_status, 'labels': ['Active', 'Inactive', 'Delayed'], 
        'realtime_site':realtime_response.json(),'category_label':chart_data_label,'category_series':chart_data_series, 'state_label':state_chart_label,
        'state_series':state_chart_series, 'station_data':total_stations_by_type, 'total_parameters':parameter_response.json(),'total_sites':total_sites, 
        'total_stations':total_stations, 'bar_chart_data':state_chart_data, 'site_status_date':date_list})

    return render(request, 'pages/login.html')
    
def staions_count(id, queue):
    ip = settings.IP
    headers = settings.HEADERS
    url = ip+f"/stations?site={id}"
    response=requests.request("GET", url, headers=headers)
    total=len(response.json())
    queue.put(total)

def parameters_count(id, queue):
    ip = settings.IP
    headers = settings.HEADERS
    url = ip+f"/parameters?site={id}"
    response=requests.request("GET", url, headers=headers)
    total=len(response.json())
    queue.put(total)

@login_required
def summary(request):
    ip = settings.IP
    headers = settings.HEADERS

    queueData = Queue.Queue()
    queueTimestamp = Queue.Queue()
    
    url = ip+"/sites/"
    sites = requests.request("GET", url, headers=headers)

    if request.session['site']:
        id = request.session['site']
    elif request.GET.get('id'):
        id = request.GET.get('id')
    else:    
        id = sites.json()[0]['id']

    realtime_site_url = ip+"/parameters/realtime-sites/"
    site_params = {'id':id}
    realtime_site=requests.request("GET", realtime_site_url, headers=headers,params=site_params)

    queueStation = Queue.Queue()
    queueParameter = Queue.Queue()
    
    thread0 = threading.Thread(target=staions_count, args=[id, queueStation], name="thread0")
    thread0.start()

    thread1 = threading.Thread(target=parameters_count, args=[id, queueParameter], name="thread0")
    thread1.start()

    thread0.join()
    thread1.join()

    total = [queueStation.get(), queueParameter.get()]

    realtime_value_url = ip+"/parameters/realtime-values"
    value_params = {'site':id}
    realtime_values=requests.request("GET", realtime_value_url, headers=headers, params=value_params)
    
    if request.GET.get('parameter'):
        first_params={'id': request.GET.get('parameter')}
    else:
        first_params={'site':id}
    first_value=requests.request("GET", realtime_value_url, headers=headers, params=first_params)

    today = datetime.datetime.today().date()
    fromDate = str(today)
    toDate = str(today)
    parameter_str = ""
    parameter_str += "&parameters="+first_value.json()[0][6]
    thread1 = threading.Thread(target=getAverageData, args=[fromDate, toDate, first_value.json()[0][2], 
                                first_value.json()[0][4], 15, parameter_str, queueData], name="thread1")
    thread1.start()
    thread2 = threading.Thread(target=getTimestamp, args=[fromDate, toDate, 15, queueTimestamp], name="thread2")
    thread2.start()

    thread1.join()
    thread2.join()
    
    data_response = queueData.get()
    timestamp = queueTimestamp.get()
    
    parameter_data = ""
    for key, value in data_response.items():
        parameter_data = [value.get(k, 'NA') for k in timestamp]
    parameter_url = ip+"/parameters"
    chart_parameter_params = {
        'station_name': first_value.json()[0][4],
        'parameter': first_value.json()[0][6]
    }
    chart_parameter_response = requests.request("GET", parameter_url, headers=headers, params=chart_parameter_params)
    chart_ranges = {
        'id': chart_parameter_response.json()[0]['id'],
        'standard_limit': chart_parameter_response.json()[0]['standard_limit'],
        'lower_min': chart_parameter_response.json()[0]['lower'],
        'upper_max': chart_parameter_response.json()[0]['upper'],
        'normal_min': chart_parameter_response.json()[0]['normal_min'],
        'normal_max': chart_parameter_response.json()[0]['normal_max'],
    }
    charts_data = [json.dumps(first_value.json()[0][6]), json.dumps(timestamp, indent=4, sort_keys=True, default=str),
    parameter_data, chart_ranges]

    return render(request, 'pages/site-summary.html', {'sites':sites.json(), 'site_data': realtime_site.json()['data'],
    'total':total, 'id':id, 'realtime_values': realtime_values.json(), 'first_value': first_value.json()[0], 
    'chart_data': charts_data})

@login_required
def dashboard(request):
    ip = settings.IP
    headers = settings.HEADERS
    username=request.session['username']
    url = ip+"/users/list/?username="+username
    widget_url = ip+"/widget/"
    data_url = ip+"/parameters/realtime-values"
    user_details = requests.request("GET", url, headers=headers)
    id=user_details.json()[0]["id"]
    user_params = {
        'user': id
    }
    widgets = requests.request("GET",widget_url,headers=headers, params=user_params)
    data = []
    for widget in widgets.json():
        params = {
            'site':widget['site'],
            'station':widget['station'],
            'parameter':widget['parameter']
        }
        get_data = requests.request("GET",data_url,headers=headers,params=params)
        for values in get_data.json():
            card_data = [widget['widget'], widget['id'],values[4], values[6], values[7],values[11], values[12], values[13],values[14]]
            data.append(card_data)
   
    return render(request, 'pages/dashboard.html',{'widgets':widgets.json(),'data':data,'site_name': request.session['site_name']})

@login_required
def dashboardsetup(request):
    ip = settings.IP
    headers = settings.HEADERS
    url = ip+f"/sites?id={request.session['site']}"
    sites = requests.request("GET", url, headers=headers)
    widget_create_url = ip+"/widget/create/"
    username=request.session['username']
    url = ip+"/users/list/?username="+username
    user_details = requests.request("GET", url, headers=headers)
    id=user_details.json()[0]["id"]
    
    if request.method == "POST":
        site = request.POST['site']
        station = request.POST['station']
        parameter = request.POST['parameter']
        widget = request.POST['widget']
        payload=json.dumps({
            'user':id,
            'site':site,
            'station':station,
            'parameter':parameter,
            'widget':widget 
        })
        user_params = {
        'user': id
        }
        get_widgets= ip+"/widget/"
        widgets = requests.request("GET",get_widgets,headers=headers, params=user_params)
        parameter_id=[]
        for w in widgets.json():
            widget_parameter_id=w['parameter']
            parameter_id.append(widget_parameter_id)
            
        if parameter in parameter_id :
            messages.warning(request, "Widget Already Exist!")
        else:
            widget_response = requests.request("POST",widget_create_url,headers=headers,data=payload)
            if widget_response.status_code == 201:
                messages.success(request, "Widget created successfully!")
            return redirect(dashboard)
    return render(request, 'pages/dashboard-setup.html',{'sites':sites.json()})

@login_required
def delWidget(request):
    ip = settings.IP
    headers = settings.HEADERS
    widget_id = request.GET['id']
    widget_del_url = ip+"/widget/destroy/"+widget_id+"/"
    widget_res = requests.request("DELETE",widget_del_url,headers=headers)
    if widget_res.json()['status'] == "success":
        messages.success(request, "Widget Deleted!")   
    else:
        messages.success(request, "Widget Not Deleted!")

    return redirect(dashboard)

@csrf_exempt
def otp(request):
    if request.method == 'POST':
        otp = request.POST['otp']
        purpose = request.POST['purpose']
        meta_data = request.META.get('HTTP_X_FORWARDED_FOR')
        if meta_data:
            ip = meta_data.split(',')[-1].strip()
        else:
            ip = request.META.get('REMOTE_ADDR')
        if otp == str(request.session['otp']):
            data = request.session['data']
            request.session['id'] = data['id']
            request.session['username'] = data['username']
            request.session['name'] = data['displayName']
            request.session['role'] = data['role']
            request.session['mobile'] = data['mobile']
            request.session['email'] = data['email']
            request.session['site'] = ""
            request.session['label'] = ""
            request.session['site_name'] = ""
            request.session['category'] = ""
            request.session['is_staff'] = data['is_staff']
            request.session['is_superuser'] = data['is_superuser']
            s2 = send_Email_CPCB(otp,data['email'],ip,purpose)
            s2.start()
            del request.session['otp']
            return redirect(summary)
        else:
            messages.warning(request, "OTP not matched!")
    return render(request,'pages/otp.html')

def resend_otp(request):
    generated_otp = random.randint(100000, 999999)
    request.session['otp'] = generated_otp
    data = request.session['data']
    s1 = Send_Email(generated_otp, data['email'])
    s1.start()
    return redirect(otp)

@login_required
def logout(request):
    username = request.session['username']
    ip = settings.IP
    headers = settings.HEADERS
    
    meta_data = request.META.get('HTTP_X_FORWARDED_FOR')
    if meta_data:
        audit_ip = meta_data.split(',')[-1].strip()
    else:
        audit_ip = request.META.get('REMOTE_ADDR')
    
    audit_url= ip + "/audit-logs/create/"
    timestamp=str(datetime.datetime.now())
    payload=json.dumps({
        "timestamp": timestamp,
        "username": username,
        "action_type": "Create",
        "action": "User log out at "+timestamp,
        "ip_address": audit_ip
        })
    audit_response=requests.request('POST',audit_url,headers=headers,data=payload)
    del request.session['username']
    
    return redirect(login)

def page_not_found(request, exception=None):
    return render(request, 'pages/404.html')

def page_forbidden(request, exception=None):
    return render(request, 'pages/403.html')

def internal_server_error(request, exception=None):
    return render(request, 'pages/500.html')

def bad_request(request, exception=None):
    return render(request, 'pages/400.html')
