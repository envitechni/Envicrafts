from django.urls import path
from . import views

urlpatterns = [
    path('login', views.login, name="login"),
    path('', views.home, name="home"),
    path('site-summary', views.summary, name="site-summary"),
    path('dashboard', views.dashboard, name="dashboard"),
    path('dashboard/setup', views.dashboardsetup, name="dashboard-setup"),
    path('delete-widget', views.delWidget, name="delete-widget"),
    path('verify-otp/', views.otp, name="otp"),
    path('resend-otp/', views.resend_otp, name="resend-otp"),
    path('logout', views.logout, name="logout"),
]
