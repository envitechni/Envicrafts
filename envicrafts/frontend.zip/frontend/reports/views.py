from django.contrib import messages
from django.shortcuts import render
from globalData.decorator import login_required
from django.conf import settings

import queue as Queue
import threading
import datetime
import json 
import requests

def getTimestamp(fromDate, toDate, interval, queue):
    timestamp = []
    fromDate = datetime.datetime.strptime(fromDate+" 00:00:00", "%Y-%m-%d %H:%M:%S")
    toDate = datetime.datetime.strptime(toDate+" 23:59:00", "%Y-%m-%d %H:%M:%S")
    date_time = fromDate
    time_delta = int(interval)
    while date_time < toDate:
        date_time += datetime.timedelta(minutes=time_delta)
        timestamp.append(datetime.datetime.strftime(date_time, "%Y-%m-%d %H:%M:%S"))
    queue.put(timestamp)

def getAverageData(fromDate, toDate, site, station, interval, parameter_str, queue):
    ip = settings.IP
    headers = settings.HEADERS
    data_url = ip+f"/data/average?from={fromDate}&to={toDate}&site={site}&station={station}&interval={interval}"+parameter_str
    data_response = (requests.request('GET', data_url, headers=headers))
    queue.put(data_response.json())

def getExceedanceData(fromDate, toDate, site, station, parameter, queue):
    ip = settings.IP
    headers = settings.HEADERS
    data_url = ip+f"/data/exceedance?from={fromDate}&to={toDate}&site={site}&station={station}&parameters={parameter}&interval=15"
    data_response = (requests.request('GET', data_url, headers=headers))
    queue.put(data_response.json())

def getPercentileData(fromDate, toDate, site, station, parameter, value, queue):
    ip = settings.IP
    headers = settings.HEADERS
    data_url = ip+f"/data/percentile?from={fromDate}&to={toDate}&site={site}&station={station}&parameters={parameter}&value={value}"
    data_response = (requests.request('GET', data_url, headers=headers))
    queue.put(data_response.json())

def getStatData(fromDate, toDate, site, station, parameter_str, queue):
    ip = settings.IP
    headers = settings.HEADERS
    stat_url = ip+f"/data/statistics?from={fromDate}&to={toDate}&site={site}&station={station}&interval=30"+parameter_str
    stat_response = (requests.request('GET', stat_url, headers=headers))
    queue.put(stat_response.json())

def getMatrixData(fromDate, toDate, site, station,interval, parameter, queue):
    ip = settings.IP
    headers = settings.HEADERS
    url = ip+f"/data/average?from={fromDate}&to={toDate}&site={site}&station={station}&parameters={parameter}&interval={interval}"
    get_response = (requests.request('GET', url, headers=headers))
    queue.put(get_response.json())

@login_required
def average(request):
    queueData = Queue.Queue()
    queueTimestamp = Queue.Queue()
    queueStatData = Queue.Queue()
    ip = settings.IP
    headers = settings.HEADERS
    # request.session['ip'] = audit_ip
    
    url = ip+f"/setup/category?id={request.session['category']}"
    response = requests.request('GET',url,headers=headers)
    username=request.session['username']

    if request.method == "POST":
        fromDate = request.POST['from']
        toDate = request.POST['to']
        category = request.POST['category']
        site = request.POST['site']
        station = request.POST['station']
        parameters = request.POST.getlist('parameter')
        interval = request.POST['interval']
        view = request.POST.getlist('view')
        if view:
            view = True
        else:
            view = False

        parameter_str = ""
        for parameter in parameters:
            parameter_str += "&parameters="+parameter
        
        thread0 = threading.Thread(target=getStatData, args=[fromDate, toDate, site, station, parameter_str, queueStatData], 
                                    name="thread0")
        thread0.start()
        thread1 = threading.Thread(target=getAverageData, args=[fromDate, toDate, site, station, interval, parameter_str, queueData], 
                                    name="thread1")
        thread1.start()
        thread2 = threading.Thread(target=getTimestamp, args=[fromDate, toDate, interval, queueTimestamp], name="thread2")
        thread2.start()

        thread1.join()
        thread2.join()

        data_response = queueData.get()
        timestamp = queueTimestamp.get()

        parameter_data = []
        for key, value in data_response.items():
            if len(value) > 0:
                parameter_data.append([value.get(k, "NA") for k in timestamp])
        
        data = []
        charts_data = []
        stat_data = {}
        if len(parameter_data) > 0 and len(parameter_data[0]) > 0:
            if view:
                for i in range(0, len(parameter_data[0])):
                    sub_list = []
                    sub_list.append(timestamp[i])
                    for j in range(0, len(parameter_data)):
                        try:
                            sub_list.append(round(parameter_data[j][i], 2))
                        except:
                            sub_list.append("NA")
                    data.append(sub_list)
            else:
                count = 0
                for parameter in parameters:
                    parameter_url = ip+"/parameters"
                    chart_parameter_params = {
                        'station_name': station,
                        'parameter': parameter
                    }
                    chart_parameter_response = requests.request("GET", parameter_url, headers=headers, params=chart_parameter_params)
                    chart_ranges = {
                        'id': chart_parameter_response.json()[0]['id'],
                        'standard_limit': chart_parameter_response.json()[0]['standard_limit'],
                        'lower_min': chart_parameter_response.json()[0]['lower'],
                        'upper_max': chart_parameter_response.json()[0]['upper'],
                        'normal_min': chart_parameter_response.json()[0]['normal_min'],
                        'normal_max': chart_parameter_response.json()[0]['normal_max'],
                    }
                    charts_data.append([json.dumps(parameter), json.dumps(timestamp, indent=4, sort_keys=True, default=str),
                    parameter_data[count], chart_ranges])
                    count += 1
            thread0.join()
            stat_data = queueStatData.get()
        else:
            messages.warning(request, "Oops! no any data found.")

        selected_data = {
            'from': fromDate,
            'to': toDate,
            'category': category,
            'site': site,
            'station': station,
            'interval': interval,
            'view': view
        }
        
        meta_data = request.META.get('HTTP_X_FORWARDED_FOR')
        if meta_data:
            audit_ip = meta_data.split(',')[-1].strip()
        else:
            audit_ip = request.META.get('REMOTE_ADDR')
        
        audit_url= ip + "/audit-logs/create/"
        timestamp=str(datetime.datetime.now())
        
        payload=json.dumps({
            "timestamp": timestamp,
            "username": username,
            "action_type": "Create",
            "action": "User has generated Average Report at "+timestamp,
            "ip_address": audit_ip
            })
        audit_response=requests.request('POST',audit_url,headers=headers,data=payload)
        return render(request, 'pages/average-report.html',{'categories':response.json(), 'data': data, 'charts_data': charts_data,
        'stat_data': stat_data, 'parameters': parameters, 'selected_data': selected_data})
        
    return render(request, 'pages/average-report.html',{'categories':response.json(),})

@login_required
def exceedance(request):
    queueData = Queue.Queue()
    queueTimestamp = Queue.Queue()
    queueStatData = Queue.Queue()
    ip = settings.IP
    headers = settings.HEADERS
    url = ip+f"/setup/category?id={request.session['category']}"
    response = requests.request('GET',url,headers=headers)
    username=request.session['username']
    
    if request.method == "POST":
        fromDate = request.POST['from']
        toDate = request.POST['to']
        category = request.POST['category']
        site = request.POST['site']
        station = request.POST['station']
        parameters = request.POST['parameter']

        parameter_str = ""
        parameter_str += "&parameters="+parameters
    
        thread0 = threading.Thread(target=getStatData, args=[fromDate, toDate, site, station, parameter_str, queueStatData], 
                                    name="thread0")
        thread0.start()
        thread1 = threading.Thread(target=getExceedanceData, args=[fromDate, toDate, site, station, parameters, queueData], 
                                    name="thread1")
        thread1.start()
        thread2 = threading.Thread(target=getTimestamp, args=[fromDate, toDate, 15, queueTimestamp], name="thread2")
        thread2.start()

        thread1.join()
        thread2.join()

        data_response = queueData.get()
        timestamp = queueTimestamp.get()

        parameter_data = ""
        for key, value in data_response.items():
            if len(value) > 0:
                parameter_data = [value.get(k, ['NA', 'N']) for k in timestamp]
            
        data = []
        stat_data = {}
        if len(parameter_data) > 0:
            for i in range(len(parameter_data)):
                    sub_list = []
                    sub_list.append(timestamp[i])
                    for d in parameter_data[i]:
                        sub_list.append(d)
                    data.append(sub_list)
            
            thread0.join()
            stat_data = queueStatData.get()
        else:
            messages.warning(request, "Oops! no any data found.")
        
        selected_data = {
            'from': fromDate,
            'to': toDate,
            'category': category,
            'site': site,
            'station': station,
            'parameter': parameters,
        }
        
        meta_data = request.META.get('HTTP_X_FORWARDED_FOR')
        if meta_data:
            audit_ip = meta_data.split(',')[-1].strip()
        else:
            audit_ip = request.META.get('REMOTE_ADDR')
        
        audit_url= ip + "/audit-logs/create/"
        timestamp=str(datetime.datetime.now())
        
        payload=json.dumps({
            "timestamp": timestamp,
            "username": username,
            "action_type": "Create",
            "action": "User has generated Exceedance report at "+timestamp,
            "ip_address": audit_ip
            })
        audit_response=requests.request('POST',audit_url,headers=headers,data=payload)

        return render(request, 'pages/exceedance-report.html',{'categories':response.json(), 'data': data,
        'stat_data': stat_data, 'parameters': parameters, 'selected_data': selected_data})
    
    return render(request, 'pages/exceedance-report.html',{'categories':response.json(),})

@login_required
def percentile(request):
    queueData = Queue.Queue()
    queueStatData = Queue.Queue()
    ip = settings.IP
    headers = settings.HEADERS
    url = ip+f"/setup/category?id={request.session['category']}"
    response = requests.request('GET',url,headers=headers)
    username=request.session['username']
    
    if request.method == "POST":
        fromDate = request.POST['from']
        toDate = request.POST['to']
        category = request.POST['category']
        site = request.POST['site']
        station = request.POST['station']
        parameters = request.POST['parameter']
        value = request.POST['number']

        parameter_str = ""
        parameter_str += "&parameters="+parameters
    
        thread0 = threading.Thread(target=getStatData, args=[fromDate, toDate, site, station, parameter_str, queueStatData], 
                                    name="thread0")
        thread0.start()
        thread1 = threading.Thread(target=getPercentileData, args=[fromDate, toDate, site, station, parameters, value, queueData], 
                                    name="thread1")
        thread1.start()        
        thread1.join()

        data_response = queueData.get()

        data = []
        stat_data = {}
        if len(data_response) > 0:
            total = sum(data_response[1])
            percentage = []
            for v in data_response[1]:
                try:
                    percentage.append(round(v * 100 / total, 2))
                except:
                    percentage.append(0.00)
            data1 = data_response[0]
            data2 = data_response[1]
            data3 = percentage
            for i in range(0, 3):
                data.append([data1[i], data2[i], data3[i]])
            thread0.join()
            stat_data = queueStatData.get()
        else:
            messages.warning(request, "Oops! no any data found.")

        selected_data = {
            'from': fromDate,
            'to': toDate,
            'category': category,
            'site': site,
            'station': station,
            'parameter': parameters,
        }
        
        meta_data = request.META.get('HTTP_X_FORWARDED_FOR')
        if meta_data:
            audit_ip = meta_data.split(',')[-1].strip()
        else:
            audit_ip = request.META.get('REMOTE_ADDR')
        
        audit_url= ip + "/audit-logs/create/"
        timestamp=str(datetime.datetime.now())
        
        payload=json.dumps({
            "timestamp": timestamp,
            "username": username,
            "action_type": "Create",
            "action": "User has generated Percentile report "+timestamp,
            "ip_address": audit_ip
            })
        audit_response=requests.request('POST',audit_url,headers=headers,data=payload)
        
        return render(request, 'pages/percentile-report.html',{'categories':response.json(), 'data': data,
        'stat_data': stat_data, 'parameters': parameters, 'selected_data': selected_data})
    
    return render(request, 'pages/percentile-report.html',{'categories':response.json(),})

@login_required
def stationwise(request):
    queueData = Queue.Queue()
    queueTimestamp = Queue.Queue()
    queueStatData = Queue.Queue()
    ip = settings.IP
    headers = settings.HEADERS
    url = ip+f"/setup/category?id={request.session['category']}"
    response = requests.request('GET',url,headers=headers)
    username=request.session['username']
    
    if request.method == "POST":
        fromDate = request.POST['from']
        toDate = request.POST['to']
        category = request.POST['category']
        site = request.POST['site']
        station = request.POST['station']
        interval = request.POST['interval']
        view = request.POST.getlist('view')
        if view:
            view = True
        else:
            view = False

        parameters = []
        parameter_params = {
            'station_name': station,
        }
        parameter_url = ip+"/parameters/"
        parameters_resp = requests.request("GET", parameter_url, headers=headers, params=parameter_params)
        for resp in parameters_resp.json():
            parameters.append(resp['parameter'])
        
        parameter_str = ""
        for parameter in parameters:
            parameter_str += "&parameters="+parameter
        
        thread0 = threading.Thread(target=getStatData, args=[fromDate, toDate, site, station, parameter_str, queueStatData], 
                                    name="thread0")
        thread0.start()
        thread1 = threading.Thread(target=getAverageData, args=[fromDate, toDate, site, station, interval, parameter_str, queueData], 
                                    name="thread1")
        thread1.start()
        thread2 = threading.Thread(target=getTimestamp, args=[fromDate, toDate, interval, queueTimestamp], name="thread2")
        thread2.start()

        thread1.join()
        thread2.join()

        data_response = queueData.get()
        timestamp = queueTimestamp.get()

        parameter_data = []
        for key, value in data_response.items():
            if len(value) > 0:
                parameter_data.append([value.get(k, "NA") for k in timestamp])
        
        data = []
        charts_data = []
        stat_data = {}
        if len(parameter_data) > 0 and len(parameter_data[0]) > 0:
            if view:
                for i in range(0, len(parameter_data[0])):
                    sub_list = []
                    sub_list.append(timestamp[i])
                    for j in range(0, len(parameter_data)):
                        try:
                            sub_list.append(round(parameter_data[j][i], 2))
                        except:
                            sub_list.append("NA")
                    data.append(sub_list)
            else:
                count = 0
                for parameter in parameters:
                    parameter_url = ip+"/parameters"
                    chart_parameter_params = {
                        'station_name': station,
                        'parameter': parameter
                    }
                    chart_parameter_response = requests.request("GET", parameter_url, headers=headers, params=chart_parameter_params)
                    chart_ranges = {
                        'id': chart_parameter_response.json()[0]['id'],
                        'standard_limit': chart_parameter_response.json()[0]['standard_limit'],
                        'lower_min': chart_parameter_response.json()[0]['lower'],
                        'upper_max': chart_parameter_response.json()[0]['upper'],
                        'normal_min': chart_parameter_response.json()[0]['normal_min'],
                        'normal_max': chart_parameter_response.json()[0]['normal_max'],
                    }
                    charts_data.append([json.dumps(parameter), json.dumps(timestamp, indent=4, sort_keys=True, default=str),
                    parameter_data[count], chart_ranges])
                    count += 1
            thread0.join()
            stat_data = queueStatData.get()
        else:
            messages.warning(request, "Oops! no any data found.")
        
        selected_data = {
            'from': fromDate,
            'to': toDate,
            'category': category,
            'site': site,
            'station': station,
            'interval': interval,
            'view': view
        }
        meta_data = request.META.get('HTTP_X_FORWARDED_FOR')
        if meta_data:
            audit_ip = meta_data.split(',')[-1].strip()
        else:
            audit_ip = request.META.get('REMOTE_ADDR')
        
        audit_url= ip + "/audit-logs/create/"
        timestamp=str(datetime.datetime.now())
        
        payload=json.dumps({
            "timestamp": str(datetime.datetime.now()),
            "username": username,
            "action_type": "Create",
            "action": "User has generated Stationwise report "+timestamp,
            "ip_address": audit_ip
            })
        audit_response=requests.request('POST',audit_url,headers=headers,data=payload)
        
        return render(request, 'pages/stationwise-report.html',{'categories':response.json(), 'data': data, 'charts_data': charts_data,
        'stat_data': stat_data, 'parameters': parameters, 'selected_data': selected_data})
    
    return render(request, 'pages/stationwise-report.html',{'categories':response.json(),})

@login_required
def exceedanceCount(request):
    queueData = Queue.Queue()
    ip = settings.IP
    headers = settings.HEADERS
    url = ip+f"/setup/category?id={request.session['category']}"
    response = requests.request('GET',url,headers=headers)
    if request.method == "POST":
        fromDate = request.POST['from']
        toDate = request.POST['to']
        category = request.POST['category']
        site = request.POST['site']
        station = request.POST['station']
        parameters = []
        parameter_params = {
            'station_name': station,
        }
        parameter_url = ip+"/parameters/"
        parameters_resp = requests.request("GET", parameter_url, headers=headers, params=parameter_params)
        for resp in parameters_resp.json():
            parameters.append(resp['parameter'])
        raw_data = []
        for parameter in parameters:
            thread1 = threading.Thread(target=getExceedanceData, args=[fromDate, toDate, site, station, parameter, queueData],name="thread1")
            thread1.start()
            thread1.join()
            data_response = queueData.get()
            print(data_response)
            for key, values in data_response.items():
                sub_list = []
                for key1, value in values.items():
                    sub_list.append(value[1])
                raw_data.append(sub_list)
        count_data = []          
        for data in raw_data:
            count=0
            for d in data:
                if(d=='E'):
                    count=count+1
            count_data.append(count)       
        selected_data = {
            'from': fromDate,
            'to': toDate,
            'category': category,
            'site': site,
            'station': station,
        }
        return render(request, 'pages/exceedance-count.html',{'categories':response.json(),'parameters': parameters, 'selected_data': selected_data, 'exceedance_count':count_data, 'site':site, 'station':station})

    return render(request, 'pages/exceedance-count.html',{'categories':response.json()})
    
@login_required
def dataAvailability(request):
    queueData = Queue.Queue()
    queueTimestamp = Queue.Queue()
    ip = settings.IP
    headers = settings.HEADERS
    url = ip+f"/setup/category?id={request.session['category']}"
    response = requests.request('GET',url,headers=headers)
    username=request.session['username']
    
    if request.method == "POST":
        fromDate = request.POST['from']
        toDate = request.POST['to']
        category = request.POST['category']
        site = request.POST['site']
        station = request.POST['station']
        parameters = request.POST.getlist('parameter')
        interval = 1
        interval1 = 1440

        parameter_str = ""
        for parameter in parameters:
            parameter_str += "&parameters="+parameter
        
        thread1 = threading.Thread(target=getAverageData, args=[fromDate, toDate, site, station, interval, parameter_str, queueData], 
                                    name="thread1")
        thread2 = threading.Thread(target=getTimestamp, args=[fromDate, toDate, interval1, queueTimestamp], name="thread2")

        thread1.start()
        thread2.start()

        thread1.join()
        thread2.join()

        data_response = queueData.get()
        data=dict()
        for parameter in parameters:
            for key, values in data_response.items():
                data[key]=dict()
                for key_, value_ in values.items():
                    data[key].setdefault(key_[:10],[]).append(value_)

        final_data = dict()
        for key, values in data.items():
            final_data[key]= dict()
            for key1, value in values.items():
                total_data_count = len(value)
                percentage_data = (total_data_count * 100)/1440
                available_data = str(percentage_data)[:5]
                final_data[key].setdefault(key1,available_data)
                
        selected_data = {
            'from': fromDate,
            'to': toDate,
            'category': category,
            'site': site,
            'station': station,
        }

        return render(request, 'pages/data-availability.html',{'categories':response.json(), 'data':final_data ,"station":station,"selected_data":selected_data,'parameters': parameters})
        
    return render(request, 'pages/data-availability.html',{'categories':response.json()})
