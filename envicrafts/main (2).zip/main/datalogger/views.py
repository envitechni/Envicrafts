from django.http.response import JsonResponse
from django.conf import settings
from django.core.mail import send_mail
from notifications.signals import notify
from datetime import datetime, date
from user.models import User
from parameters.models import Parameter, RealtimeValue
from data.models import DataModel as Data
from settings.models import Email
from .models import Token
from threading import *
from sites.models import Sites
from .tasks import get_realtime_data, get_delayed_data
from django.http import HttpResponse
from requests_http_signature import HTTPSignatureAuth
from base64 import b64decode
import time
import requests
import json

def set_exceedance(user, date_pass, site, station, parameter, value):
    para = Parameter.objects.get(site__label=site, station__station=station, parameter=parameter)
    email_settings = Email.objects.filter(site__label=site, station__station=station, parameter=parameter).all().count()

    today_date = date.today()
    date_received = datetime.strptime(date_pass, "%Y-%m-%d %H:%M:%S.%f")
    date_received = datetime.strftime(date_received, "%Y-%m-%d")
    if not str(today_date) == date_received:
        Sites.objects.filter(label=site).update(today_exceedance=0)

    if para.standard_limit:
        if float(value) < para.normal_min or float(value) > para.normal_max:
            sites = Sites.objects.get(label=site)
            exceedance = sites.today_exceedance
            Sites.objects.filter(label=site).update(today_exceedance=exceedance+1)
            t1 = SendNotification(user, date_pass, site, station, parameter)
            t1.start()
            
    if email_settings > 0:
        t2 = SendEmail(date_pass, site, station, parameter, value)
        t2.start()

def realtime_value(site, station, parameter, value, date):
    get_realtimevalue = RealtimeValue.objects.get(site=site,station=station,parameter=parameter)

    last_sync_date = get_realtimevalue.last_sync
    first_sync_date = get_realtimevalue.first_sync

    if first_sync_date == None or first_sync_date == "NULL":
        update_realtimevalue = RealtimeValue.objects.filter(id=get_realtimevalue.id).update(
            last_value = value,
            today_max = value,
            today_min = value,
            first_sync = date,
            last_sync = date,
        )
    elif last_sync_date == 'NULL' or last_sync_date == None:
            update_realtimevalue = RealtimeValue.objects.filter(id=get_realtimevalue.id).update(
                last_value = value,
                today_max = value,
                today_min = value,
                last_sync = date,
            )
    else:
        last_date = str(get_realtimevalue.last_sync)
        last_date = last_date[:19]
        last_date = datetime.strptime(last_date,"%Y-%m-%d %H:%M:%S")
        last_date = datetime.strftime(last_date,"%Y-%m-%d")

        last_realtime_date = date
        last_realtime_date = datetime.strptime(last_realtime_date,"%Y-%m-%d %H:%M:%S.%f")
        last_realtime_date = datetime.strftime(last_realtime_date,"%Y-%m-%d")

        if last_realtime_date != last_date:
            update_realtimevalue = RealtimeValue.objects.filter(id=get_realtimevalue.id).update(
                last_value = value,
                today_max = value,
                today_min = value,
                last_sync = date,
            )
        else:
            if float(value) < get_realtimevalue.today_min:
                update_realtimevalue = RealtimeValue.objects.filter(id=get_realtimevalue.id).update(
                    last_value = value,
                    today_min = value,
                    last_sync = date,
                )
            elif float(value) > get_realtimevalue.today_max:
               update_realtimevalue = RealtimeValue.objects.filter(id=get_realtimevalue.id).update(
                    today_max = value,
                    last_value = value,
                    last_sync = date,
                )
            else:
                update_realtimevalue = RealtimeValue.objects.filter(id=get_realtimevalue.id).update(
                    last_value = value,
                    last_sync = date,
                )

class SendNotification(Thread):
    def __init__(self, user, date, site, station, parameter):
        Thread.__init__(self)
        self.user = user
        self.date = date
        self.site = site
        self.station = station
        self.parameter = parameter

    def run(self):
        sender = self.user
        recipient = User.objects.filter(is_staff=False, site__label=self.site).all()
        verb = "Exceedance occurs in Site: " + self.site
        description = "Exceedance occurs in Device: " + self.station + "'s Parameter: " + self.parameter + " on " + str(self.date)
        notify.send(sender=sender, recipient=recipient, verb=verb, description=description, level="warning")
        return True

class SendEmail(Thread):
    def __init__(self, date, site, station, parameter, value):
        Thread.__init__(self)
        self.date = str(date)
        self.site = str(site)
        self.station = str(station)
        self.parameter = str(parameter)
        self.value = str(value)
     
    def run(self):
        recipient_list = ['namitatare@technicrafts.in',]
        subject = 'Warning! Parameter Limit Exceed. '
        message = "This mail is a warning for the parameter limit exceed on" + "\nTimestamp: " + self.date + "\nSite: " +  self.site + "\nDevice: " + self.station + "\nParameter: " + self.parameter + "\nValue: " + self.value + "\n\nRegards," + "\nTechniCrafts Enviro Solutions."
        email_from = settings.EMAIL_HOST_USER
        send_mail(subject, message, email_from, recipient_list) 
        return True

def get_data(request):
    key = request.headers['Authorization']
    key = key.split(' ')
    data = json.loads(request.body)
    if key[1] == "b7961c713947e889e35e170684ec66eaf9b4bb40":
        get_realtime_data.delay(data) #for call the function which is created in tasks.py'
        response = {
                "Data stored successfully...",
            }
    else:
        response = {
            "error!!!",
            "Key is not valid...",
        } 
    return HttpResponse(response)


def delayed_data(request):
    key = request.headers['Authorization']
    key = key.split(' ')
    data = json.loads(request.body)
    if key[1] == "b7961c713947e889e35e170684ec66eaf9b4bb40":
        get_delayed_data.delay(data)
        response = {
                "Delayed Data stored successfully...",
            }
    else:
        response = {
            "error!!!",
            "Key is not valid...",
        } 
    return HttpResponse(response)  

def getData(request):
        key = request.GET['key']
        date = request.GET['date']
        site = request.GET['site']
        station = request.GET['station']
        parameter = request.GET['parameter']
        value = request.GET['value']

        if Token.objects.filter(key=key).exists():
            token = Token.objects.get(key=key)
            user = User.objects.get(id=token.user_id)

            if user.username == "datalogger":
                data = Data.objects.create(dateTime=date, site=site, station=station, parameter=parameter, values=value)
                data.save()
                if(float(value) >= 0):
                    set_exceedance(user, date, site, station, parameter, value)

                get_para =  Parameter.objects.get(site__label=site,station__station=station,parameter=parameter)
                realtime_value(get_para.site_id,get_para.station_id,get_para.id,value,date)
                response = {
                    'info': "success",
                    'message': "Data stored successfully",
                }
            else:
                response = {
                    'info': "error",
                    'message': "User is not authorised",
                }
        else:
            response = {
                'info': "error",
                'message': "Key is not valid",
            }
        return JsonResponse(response, safe=False)


class SendMailRemoteOffline(Thread):
    def __init__(self, offline_list):
        Thread.__init__(self)
        self.offline_list = offline_list
        
    def run(self):
        subject = 'Data Monitoring System Datalogger Is Offline'
        message = "Dear Sir/Ma'am \nPlease note that your device for Data Monitoring System is went Offline Please Check Internet Connection" 
        email_from = settings.EMAIL_HOST_USER
        send_mail(subject, message, email_from, self.offline_list)
        return True

class SendMailRemoteOnline(Thread):
    def __init__(self, online_list):
        Thread.__init__(self)
        self.online_list = online_list

    def run(self):
        subject = 'Data Monitoring System Datalogger Is Online'
        message = "Dear Sir/Ma'am  \nWe would like to inform you that your device for Data Monitoring System is online." 
        email_from = settings.EMAIL_HOST_USER
        send_mail(subject, message, email_from, self.online_list)
        return True

def sendMailRemoteIT(request):
    key_id = 'QTQCMRQYC3AOKHBTZNV6'
    key_secret_id = 'EzxPjWbOhcqFalQ+OfuVddxGR/2gtf3ZKOBUOjzy'
    api_key = 'MTYyQUVFRTEtOUI4Ny00OUNBLUJCMkItRjU5QkJDMjY0RTE4'

    body = ''  #update this with your data if posting with a body
    host = 'api.remote.it'
    url_path = '/apv/v27/device/list/all'
    content_type_header = 'application/json'
    content_length_header = str(len(body))
    headers = {
        'host': host,
        'content-type': content_type_header,
        'content-length': content_length_header,
        'DeveloperKey': api_key
    }
    response = requests.get('https://' + host + url_path,
                            auth=HTTPSignatureAuth(algorithm="hmac-sha256",
                                                key=b64decode(key_secret_id),
                                                key_id=key_id,
                                                headers=[
                                                    '(request-target)', 'host',
                                                    'date', 'content-type',
                                                    'content-length'
                                                ]),
                            headers=headers)

    online_list = []
    ofline_list = []
    for device in response.json()['devices']:
        if device['servicetitle'] == 'Bulk Service':
            if device['devicestate'] == 'inactive':
                Offuser= User.objects.filter(remoteit=device['devicealias']).values().all()
                for us in Offuser:
                    ofline_list.append(us['email'])
                for i in range(len(ofline_list)):
                    t3 = SendMailRemoteOffline(ofline_list)
                    t3.start()
            elif device['devicestate'] == 'active':
                Onuser = User.objects.filter(remoteit=device['devicealias']).values().all()
                for usr in Onuser:
                    online_list.append(usr['email'])
                for i in range(len(online_list)):
                    t4 = SendMailRemoteOnline(online_list)
                    t4.start()
    return HttpResponse(request)



