from django.contrib import admin
from .models import EmailSettings

# Register your models here.
admin.site.register(EmailSettings)
