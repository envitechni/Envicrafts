from rest_framework import serializers
from datalogger.models import EmailSettings

class EmailSerializer(serializers.ModelSerializer):
    class Meta:
        model = EmailSettings
        fields = ['id', 'to', 'subject', 'description', 'timestamp']
