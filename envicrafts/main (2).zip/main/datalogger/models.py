from pyexpat import model
from django.db import models
from user.models import User

import datetime

# Create your models here.
class Token(models.Model):
    key = models.CharField(max_length=100)
    created = models.DateTimeField(default=datetime.datetime.now())
    user = models.ForeignKey(User,  on_delete=models.DO_NOTHING)


class EmailSettings(models.Model):
    to = models.CharField(max_length=100)
    subject = models.CharField(max_length=100)
    description = models.CharField(max_length=200)
    timestamp = models.DateTimeField(default=datetime.datetime.now())
