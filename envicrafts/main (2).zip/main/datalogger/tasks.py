from celery import Celery
from celery import shared_task
import json
from datalogger.models import EmailSettings 
from user.models import User
from data.models import DataModel as Data
from parameters.models import Parameter, RealtimeValue
from settings.models import Email
from datetime import datetime, date
from sites.models import Sites
from threading import *
from notifications.signals import notify
from django.core.mail import send_mail
from django.conf import settings


class SetExceedance(Thread):
    def __init__(self, user, date, site, station, parameter, value):
        Thread.__init__(self)
        self.user = user
        self.date = date
        self.site = site
        self.station = station
        self.parameter = parameter
        self.value = value

    def run(self):
        para = Parameter.objects.get(site__label=self.site, station__station=self.station, parameter=self.parameter)
        today_date = date.today()
        date_received = datetime.strptime(self.date, "%Y-%m-%d %H:%M:%S.%f")
        date_received = datetime.strftime(date_received, "%Y-%m-%d")
        if not str(today_date) == date_received:
            Sites.objects.filter(label=self.site).update(today_exceedance=0)

        if para.standard_limit:
            if float(self.value) < para.normal_min or float(self.value) > para.normal_max:
                sites = Sites.objects.get(label=self.site)
                exceedance = sites.today_exceedance
                Sites.objects.filter(label=self.site).update(today_exceedance=exceedance+1)

                sender = self.user
                recipients = User.objects.filter(is_email=True,is_staff=False, site__label=self.site).values().all()
                notification_recipient = User.objects.filter(is_email=True, is_staff=False, site__label=self.site).all()
                verb = "Exceedance occurs in Site: " + self.site
                description = "Exceedance occurs in Device: " + self.station + "'s Parameter: " + self.parameter + " on " + str(self.date)
                recipient_mail_list = []
                for recipient in recipients:
                    recipient_mail_list.append(recipient['email'])
                notify.send(sender=sender, recipient=notification_recipient, verb=verb, description=description, level="warning")
                
        return True
        
        
class SenMail(Thread):
    def __init__(self, user, date, site, station, parameter, value):
        Thread.__init__(self)
        self.user = user
        self.date = date
        self.site = site
        self.station = station
        self.parameter = parameter
        self.value = value

    def run(self):
      para = Parameter.objects.get(site__label=self.site, station__station=self.station, parameter=self.parameter)
      if para.standard_limit:
        if float(self.value) < para.normal_min or float(self.value) > para.normal_max:
          recipients = User.objects.filter(is_email=True,is_staff=False, site__label=self.site).values().all()
          recipient_mail_list = []
          for recipient in recipients:
            recipient_mail_list.append(recipient['email'])
            subject = 'Warning! Parameter Limit Exceed. '
            message = "This mail is a warning for the parameter limit exceed on" + "\nTimestamp: " + str(self.date) + "\nSite: " +  str(self.site) + "\nDevice: " + str(self.station) + "\nParameter: " + str(self.parameter) + "\nValue: " + str(self.value) + "\n\nRegards," + "\nTechniCrafts Enviro Solutions."
            email_from = settings.EMAIL_HOST_USER
            send_mail(subject, message, email_from, recipient_mail_list)
            for receip in recipient_mail_list:
              email_store = EmailSettings.objects.create(to=receip, subject=subject, description=message, timestamp=self.date)
              print(email_store)
              email_store.save()
      return True


@shared_task()
def get_realtime_data(data):
    user = User.objects.get(id=13)
    for key, value in data['parameters'].items():
        data_store = Data.objects.create(dateTime=data['date'], site=data['site'], station=data['station'], parameter=key, values=value)
        data_store.save()
        if(float(value) >= 0):
            t2 = SenMail(user, data['date'], data['site'], data['station'], key, value)
            t2.start()
            x = data['date'].split(" ")[1]
            y = x.split(":")
            total = int(y[0]) * 60 + int(y[1])
            if total % 15 == 0:
                t1 = SetExceedance(user, data['date'], data['site'], data['station'], key, value)
                t1.start()

        get_para =  Parameter.objects.get(site__label=data['site'],station__station=data['station'],parameter=key)
        get_realtimevalue = RealtimeValue.objects.filter(site=get_para.site_id,station=get_para.station_id,parameter=get_para.id).values()
        last_sync_date = get_realtimevalue[0]['last_sync']
        first_sync_date = get_realtimevalue[0]['first_sync']

        if first_sync_date == None or first_sync_date == "NULL":
            update_realtimevalue = RealtimeValue.objects.filter(id=get_realtimevalue[0]['id']).update(
                last_value = value,
                today_max = value,
                today_min = value,
                first_sync = data['date'],
                last_sync = data['date'],
            )
        elif last_sync_date == 'NULL' or last_sync_date == None:
                update_realtimevalue = RealtimeValue.objects.filter(id=get_realtimevalue[0]['id']).update(
                    last_value = value,
                    today_max = value,
                    today_min = value,
                    last_sync = data['date'],
                )
        else:
            last_date = str(get_realtimevalue[0]['last_sync'])
            last_date = last_date[:19]
            last_date = datetime.strptime(last_date,"%Y-%m-%d %H:%M:%S")
            last_date = datetime.strftime(last_date,"%Y-%m-%d")

            last_realtime_date = data['date']
            last_realtime_date = datetime.strptime(last_realtime_date,"%Y-%m-%d %H:%M:%S.%f")
            last_realtime_date = datetime.strftime(last_realtime_date,"%Y-%m-%d")

            if last_realtime_date != last_date:
                update_realtimevalue = RealtimeValue.objects.filter(id=get_realtimevalue[0]['id']).update(
                    last_value = value,
                    today_max = value,
                    today_min = value,
                    last_sync = data['date'],
                )
            else:
                if float(value) < get_realtimevalue[0]['today_min']:
                    update_realtimevalue = RealtimeValue.objects.filter(id=get_realtimevalue[0]['id']).update(
                        last_value = value,
                        today_min = value,
                        last_sync = data['date'],
                    )
                elif float(value) > get_realtimevalue[0]['today_max']:
                    update_realtimevalue = RealtimeValue.objects.filter(id=get_realtimevalue[0]['id']).update(
                            today_max = value,
                            last_value = value,
                            last_sync = data['date'],
                        )
                else:
                    update_realtimevalue = RealtimeValue.objects.filter(id=get_realtimevalue[0]['id']).update(
                        last_value = value,
                        last_sync = data['date'],
                    )
    return True

@shared_task()
def get_delayed_data(data):
    for key, value in data['parameters'].items():
            delayed_data_store = Data.objects.create(dateTime=data['date'], site=data['site'], station=data['station'], parameter=key, values=value)
            delayed_data_store.save()
