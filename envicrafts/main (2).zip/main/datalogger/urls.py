from django.urls import path
from . import views
from .api import EmailViewSet

urlpatterns = [
    path('get-data/', views.getData, name="get-data"),
    path('get-data-v2/', views.get_data, name="get-data-v2"),
    path('delayed-data/', views.delayed_data, name="delayed-data"),
    path('logs/email', EmailViewSet.as_view({'get': 'list'})),
    path('send-mail/', views.sendMailRemoteIT, name="send-mail"),
]