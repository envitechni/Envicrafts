
from rest_framework.viewsets import ModelViewSet
from datalogger.models import EmailSettings
from datalogger.serializer import EmailSerializer
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework.pagination import PageNumberPagination
from rest_framework.filters import SearchFilter, OrderingFilter

class Pagination(PageNumberPagination):
    page_size = 50
    page_size_query_param = 'page_size'
    max_page_size = 100

class EmailViewSet(ModelViewSet):
    queryset = EmailSettings.objects.all()
    serializer_class = EmailSerializer
    filter_backends = [DjangoFilterBackend, SearchFilter, OrderingFilter]
    pagination_class = Pagination
    search_field = ['to']
    filterset_fields = ['id', 'to', 'subject', 'description', 'timestamp']
    ordering_fields = ['id', 'to', 'subject', 'description', 'timestamp']        
