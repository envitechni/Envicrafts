from . models import Stations
from django.http.response import JsonResponse
from rest_framework.decorators import api_view

@api_view(('GET',))
def stations(request):
    headers = request.headers
    if headers is not None:
        if request.GET.get('site') and request.GET.get('monitoring_type') and request.GET.get('status'):
            stations_obj = Stations.objects.filter(site=request.GET.get('site'), 
            monitoring_type=request.GET.get('monitoring_type'), status=request.GET.get('status')).all()
        elif request.GET.get('site') and request.GET.get('monitoring_type'):
            stations_obj = Stations.objects.filter(site=request.GET.get('site'), 
            monitoring_type=request.GET.get('monitoring_type')).all()
        elif request.GET.get('site') and request.GET.get('status'):
            stations_obj = Stations.objects.filter(site=request.GET.get('site'), 
            status=request.GET.get('status')).all()
        elif request.GET.get('monitoring_type') and request.GET.get('status'):
            stations_obj = Stations.objects.filter(monitoring_type=request.GET.get('monitoring_type'), 
            status=request.GET.get('status')).all()
        elif request.GET.get('site'):
            stations_obj = Stations.objects.filter(site=request.GET.get('site')).all()
        elif request.GET.get('monitoring_type'):
            stations_obj = Stations.objects.filter(monitoring_type=request.GET.get('monitoring_type')).all()
        elif request.GET.get('status'):
            stations_obj = Stations.objects.filter(status=request.GET.get('status')).all()
        elif request.GET.get('site_label'):
            stations_obj = Stations.objects.filter(site__label=request.GET.get('site_label')).all()
        else:
            stations_obj = Stations.objects.all()
            
        station_data = [{'id': station.id, 'station': station.station, 'site_name': station.site.name, 'site_label': station.site.label, 
        'status': station.status, 'monitoring_type':  station.monitoring_type, 'make': station.make, 'model': station.model,
        'configured_date': station.configure_date, 'expiry_date': station.expiry_date} 
        for station in stations_obj]
        response = station_data
    else: 
        response = {
            'status': "failed",
            'message': "Request has no header",
        }
    return JsonResponse(response, safe=False)

@api_view(('GET',))
def typeWiseStations(request):
    headers = request.headers
    if headers is not None:
        types = ['effluent', 'emission']
        raw_data = {}
        for type in types:
            raw_data[type] = Stations.objects.filter(monitoring_type=type).all().count()

        response = {
                'status': "success",
                'data': raw_data
            }
    else: 
        response = {
            'status': "failed",
            'message': "Request has no header",
        }
    return JsonResponse(response, safe=False)
