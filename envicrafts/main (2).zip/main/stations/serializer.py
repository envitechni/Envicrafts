from rest_framework import serializers
from .models import Stations

class StationUpdateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Stations
        fields = ['station','monitoring_type','site','latitute','longitude','make','model',
        'configure_date','start_date','expiry_date', 'status']