from rest_framework.viewsets import ModelViewSet
from rest_framework.response import Response

from .models import Stations
from .serializer import StationUpdateSerializer

# Introduction viewset
class StationUpdateViewSet(ModelViewSet):
    queryset = Stations
    serializer_class = StationUpdateSerializer
        
    def update(self, request, *args, **kwargs):
        partial = kwargs.pop('partial', True)
        instance = self.get_object()
        serializer = self.get_serializer(instance, data=request.data, partial=partial)
        serializer.is_valid(raise_exception=True)
        self.perform_update(serializer)
        return Response(serializer.data)
