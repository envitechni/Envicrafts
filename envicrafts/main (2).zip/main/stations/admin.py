from django.contrib import admin
from .models import Stations

# Register your models here.

class StationsAdmin(admin.ModelAdmin):
    list_display = ('station','monitoring_type','site','latitute','longitude','make','model','configure_date','start_date','expiry_date','status')
    list_filter = ('station', 'monitoring_type', 'site','status')

admin.site.register(Stations, StationsAdmin)