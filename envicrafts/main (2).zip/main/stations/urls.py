from django.urls import path
from rest_framework import views
from .api import StationUpdateViewSet
from . import views

urlpatterns = [
    path('', views.stations, name="station"),
    path('station-count', views.typeWiseStations, name="station-count"),
    path('station/patch/<int:pk>/', StationUpdateViewSet.as_view({'patch': 'update'})),
]