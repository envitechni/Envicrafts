from django.db import models
from sites.models import Sites

# Create your models here.
monitoring_type_choises = (       
    ("ambient", "Ambient"),            
    ("effluent", "Effluent"),           
    ("emission", "Emission"),
)
class Stations(models.Model):
    station = models.CharField(max_length=50,unique=True)
    monitoring_type = models.CharField(max_length = 50, choices = monitoring_type_choises, default = 'ambient')
    site    = models.ForeignKey(Sites,on_delete=models.CASCADE,null=True)
    latitute  = models.CharField(max_length=100)
    longitude = models.CharField(max_length=100)
    make = models.CharField(max_length=100)
    model = models.CharField(max_length=100)
    configure_date =models.DateField()
    start_date = models.DateField()
    expiry_date = models.DateField()
    device_address = models.CharField(max_length=100, default=0)
    status = models.BooleanField(max_length=100)

    class Meta:
        verbose_name = "Station"
        verbose_name_plural = "Stations"
    
    def __str__(self):
        return str(self.station)