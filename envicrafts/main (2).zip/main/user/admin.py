from django.contrib import admin
from django.contrib.auth.models import Group
from django.contrib.auth.admin import UserAdmin
from .models import User
from .form import UserCreationForm
from .form import UserChangeForm

# Register your models here.

class UserAdmin(UserAdmin):
    form = UserChangeForm
    add_form = UserCreationForm

    list_display = ('username', 'displayName', 'mobile', 'is_staff', 'is_active', 'join')
    fieldsets = (
        ('Login Credentials', {'fields': ('username', 'password')}),
        ('Personal Details', {'fields': ('displayName', 'role', 'mobile', 'email', 'remoteit')}),
        ('Job Details', {'fields': ('authority', 'site', 'join', 'is_active', 'is_staff', 'is_sms', 'is_email')}),
        ('Permission', {'fields': ('user_permissions',)}),
    )
    add_fieldsets = (
        ('Login Credentials', {'fields': ('username', 'password1', 'password2')}),
        ('Personal Details', {'fields': ('displayName', 'role', 'mobile', 'email')}),
        ('Job Details', {'fields': ('site', 'join', 'is_active', 'is_staff', 'is_sms', 'is_email')}),
        ('Permission', {'fields': ('user_permissions',)}),
    )
    ordering = ('username',)
    search_fields = ['username',]
    list_filter = ['site', 'is_staff']
    
    def get_readonly_fields(self, request, obj=None):
        if obj:
            return self.readonly_fields + ('username', 'join')
        return self.readonly_fields

admin.site.register(User, UserAdmin)

admin.site.site_title = "E-Crafts Administrator - TechniCrafts"
admin.site.site_header = "E-Crafts | Technicrafts"

admin.site.unregister(Group)
