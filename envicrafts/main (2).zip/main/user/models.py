from django.db import models
from django.contrib.auth.models import AbstractBaseUser
from django.contrib.auth.models import PermissionsMixin
from django.utils import timezone

from .manager import UserManager
from sites.models import Sites
from setup.models import Authority

# Create your models here.
class User(AbstractBaseUser, PermissionsMixin):
    ROLE_CHOICES = [
        ('Admin', 'Administrator'),
        ('Operator', 'Operator'),
    ]
    username = models.CharField(max_length=100, unique=True)
    displayName = models.CharField(verbose_name="Display Name", max_length=100, blank=True)
    role = models.CharField(max_length=100, choices=ROLE_CHOICES, default="Normal")
    mobile = models.CharField(verbose_name="Mobile", max_length=50, blank=True)
    email = models.EmailField(verbose_name="Email Address")
    site = models.ForeignKey(Sites, blank=True, null=True, on_delete=models.CASCADE)
    is_active = models.BooleanField(default=True)
    is_staff = models.BooleanField(default=True)
    is_superuser = models.BooleanField(default=False)
    join = models.DateField(default=timezone.now)
    authority = models.ForeignKey(Authority, blank=True, null=True, on_delete=models.CASCADE)
    is_sms = models.BooleanField(default=False)
    is_email = models.BooleanField(default=False)
    remoteit = models.CharField(max_length=200,null=True)

    USERNAME_FIELD = 'username'

    objects = UserManager()
