from .models import User
from django.http.response import JsonResponse
from django.contrib.auth import authenticate
from rest_framework.decorators import api_view

@api_view(('POST',))
def login(request):
    headers = request.headers
    if headers is not None:
        data = request.data
        if data:
            username = data['username']
            password = data['password']
            user = authenticate(username=username, password=password)
            if user is not None:
                if user.is_active:
                    user_obj = User.objects.get(username=username)
                    if user_obj.is_staff == False:
                        data = {'id': user_obj.id, 'username': user_obj.username, 'displayName': user_obj.displayName, 'role': user_obj.role, 'mobile': user_obj.mobile, 'email': user_obj.mobile, 'email': user_obj.email, 'site': user_obj.site.id,
                            'label': user_obj.site.label, 'site_name': user_obj.site.name, 'category': user_obj.site.category.id, 'is_active': user_obj.is_active, 'is_staff': user_obj.is_staff, 'is_superuser': user_obj.is_superuser, 'join': user_obj.join, 'authority': user_obj.authority}
                    elif user_obj.authority:
                        data = {'id': user_obj.id, 'username': user_obj.username, 'displayName': user_obj.displayName, 'role': user_obj.role, 'mobile': user_obj.mobile, 'email': user_obj.mobile, 'email': user_obj.email, 'is_active': user_obj.is_active, 'is_staff': user_obj.is_staff, 'is_superuser': user_obj.is_superuser, 'join': user_obj.join, 'authority': user_obj.authority.id}
                    else:
                        data = {'id': user_obj.id, 'username': user_obj.username, 'displayName': user_obj.displayName, 'role': user_obj.role, 'mobile': user_obj.mobile, 'email': user_obj.mobile, 'email': user_obj.email, 'is_active': user_obj.is_active, 'is_staff': user_obj.is_staff, 'is_superuser': user_obj.is_superuser, 'join': user_obj.join, 'authority': user_obj.authority}
                    response = {
                        'status': "success",
                        'data': data
                    }
                else:
                    response = {
                        'status': "failed",
                        'message': "User is blocked",
                    }
            else:
                response = {
                    'status': "failed",
                    'message': "Incorrect username or password",
                }
        else:
            response = {
                'status': "failed",
                'message': "Request has no body",
            }
    else:
        response = {
            'status': "failed",
            'message': "Request has no header",
        }
    return JsonResponse(response, safe=False)

@api_view(('PATCH',))
def changePassword(request):
    headers = request.headers
    if headers is not None:
        data = request.data
        if data:
            username = data['username']
            old_password = data['old_password']
            new_password = data['new_password']
            user = authenticate(username=username, password=old_password)
            if user is not None:
                if user.is_active:
                    user_obj = User.objects.get(username=username)
                    user_obj.set_password(new_password)
                    user_obj.save()
                    response = {
                        'status': "success",
                        'message': "Password changed"
                    }
                else:
                    response = {
                        'status': "failed",
                        'message': "User is blocked",
                    }
            else:
                response = {
                    'status': "failed",
                    'message': "Incorrect username or password",
                }
        else:
            response = {
                'status': "failed",
                'message': "Request has no body",
            }
    else:
        response = {
            'status': "failed",
            'message': "Request has no header",
        }
    return JsonResponse(response, safe=False)
