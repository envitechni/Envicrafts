from rest_framework import serializers

from .models import User

class UserSerializer(serializers.ModelSerializer):
    site = serializers.CharField(source='site.label', read_only=True)
    class Meta:
        model = User
        fields = ['id', 'username', 'displayName', 'role', 'mobile', 'email', 'site', 'is_active', 'is_staff', 'is_superuser',
        'join','authority']