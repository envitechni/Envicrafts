from django_filters.rest_framework import DjangoFilterBackend
from rest_framework.filters import SearchFilter, OrderingFilter
from rest_framework.viewsets import ModelViewSet
from rest_framework.response import Response
from .models import User
from .serializer import UserSerializer

# Introduction viewset
class UserViewSet(ModelViewSet):
    queryset = User.objects.all()
    serializer_class = UserSerializer
    filter_backends = [DjangoFilterBackend, SearchFilter, OrderingFilter]
    filterset_fields = ['id', 'username', 'role', 'site', 'is_active', 'is_staff', 'is_superuser', 'is_sms', 'is_email','authority']
    ordering_fields = ['id', 'displayName']

class UserUpdateViewset(ModelViewSet):
    queryset = User
    serializer_class = UserSerializer
    
    def update(self, request, *args, **kwargs):
        partial = kwargs.pop('partial', True)
        instance = self.get_object()
        serializer = self.get_serializer(instance, data=request.data, partial=partial)
        serializer.is_valid(raise_exception=True)
        self.perform_update(serializer)
        return Response(serializer.data)
