from django.urls import path

from .api import UserViewSet, UserUpdateViewset
from . import views

urlpatterns = [
    path('list/', UserViewSet.as_view({'get': 'list'})),
    path('login/', views.login),
    path('change-password/', views.changePassword),
    path('patch/<int:pk>/', UserUpdateViewset.as_view({'patch': 'update'})),
]