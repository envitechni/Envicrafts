from rest_framework.decorators import api_view
from django.http.response import JsonResponse
from django.http import JsonResponse
from .models import Widget

# Create your views here.

@api_view(('DELETE',))
def deleteWidget(request, pk):
    token = request.headers
    if token is not None:
        try:
            # id = request.GET['id']
            Widget.objects.filter(id=pk).delete()
            message = {
                'status': "success",
                'message': "Widget Deleted!"
            }
        except:
            message = {
                'status': "Failed",
                'message': "Widget can't delete! Try again."
            }
    else:
        message = {
            'status': "Failed",
            'message': "Request has no headers"
        }
    return JsonResponse(message, safe=False)

