from django.urls import path
from . import views
from .api import WidgetViewSet, WidgetCreateViewSet

urlpatterns = [
    path('widget/', WidgetViewSet.as_view({'get': 'list'})),
    path('widget/create/', WidgetCreateViewSet.as_view({'post': 'create'})),
    path('widget/destroy/<int:pk>/', views.deleteWidget, name="widget-delete"),

]
