from django.db import models

# Create your models here.
class Widget(models.Model):
    WIDGET_CHOICES = [
        ('Gauge', 'Gauge'),
        ('Card', 'Card'),
    ]
    user = models.CharField(max_length=100)
    site = models.CharField(max_length=100)
    station = models.CharField(max_length=100)
    parameter = models.CharField(max_length=100)
    widget = models.CharField(max_length=50, choices=WIDGET_CHOICES)