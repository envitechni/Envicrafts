from django_filters.rest_framework import DjangoFilterBackend
from rest_framework.filters import SearchFilter, OrderingFilter
from rest_framework.viewsets import ModelViewSet

from .models import Widget
from .serializer import WidgetSerializer, WidgetSerializerCreate

# Introduction viewset
class WidgetViewSet(ModelViewSet):
    queryset = Widget.objects.all()
    serializer_class = WidgetSerializer
    filter_backends = [DjangoFilterBackend, SearchFilter, OrderingFilter]
    filterset_fields = ['user', 'site', 'station', 'parameter','widget']
    ordering_fields = ['user', 'site', 'station', 'parameter', 'widget']

class WidgetCreateViewSet(ModelViewSet):
    queryset = Widget.objects.all()
    serializer_class = WidgetSerializerCreate


