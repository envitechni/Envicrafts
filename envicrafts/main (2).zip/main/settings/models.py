from django.db import models
from sites.models import Sites
from stations.models import Stations

# Create your models here.
class Email(models.Model):
    RANGE_CHOICES = [
        ('less', 'Less Than'),
        ('greater', 'Greater Than'),
        ('equal', 'Equal To'),
    ]
    site = models.ForeignKey(Sites, on_delete=models.CASCADE)
    station = models.ForeignKey(Stations, on_delete=models.CASCADE)
    parameter = models.CharField(max_length=100)
    function = models.CharField(max_length=50, choices=RANGE_CHOICES)
    value = models.FloatField(default=0)
    email = models.EmailField(max_length=100)