from rest_framework import serializers
from .models import Email

class EmailSerializer(serializers.ModelSerializer):
    site = serializers.CharField(source='site.label', read_only=True)
    station = serializers.CharField(source='station.station', read_only=True)

    class Meta:
        model = Email
        fields = '__all__'

class EmailSerializerCreate(serializers.ModelSerializer):
    class Meta:
        model = Email
        fields = ['site', 'station', 'parameter', 'function', 'value', 'email']

