from django.contrib import admin
from .models import Email

# Register your models here.

class EmailAdmin(admin.ModelAdmin):
    list_display = ('id','site', 'station', 'parameter', 'function', 'email')
    list_filter = ('site', 'station')
    
admin.site.register(Email, EmailAdmin)
