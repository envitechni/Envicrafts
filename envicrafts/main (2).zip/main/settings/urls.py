from django.urls import path
from .api import EmailViewSet, EmailCreateViewSet
from . import views

urlpatterns = [
    path('email/list/', EmailViewSet.as_view({'get': 'list'})),
    path('email/create/', EmailCreateViewSet.as_view({'post': 'create'})),
    path('email/destroy/<int:pk>/', views.deleteEmail, name="email-delete")
   
]
