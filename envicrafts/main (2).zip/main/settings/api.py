from django_filters.rest_framework import DjangoFilterBackend
from rest_framework.filters import SearchFilter, OrderingFilter
from rest_framework.viewsets import ModelViewSet

from .models import Email
from .serializer import EmailSerializer, EmailSerializerCreate

# Introduction viewset
class EmailViewSet(ModelViewSet):
    queryset = Email.objects.all()
    serializer_class = EmailSerializer
    filter_backends = [DjangoFilterBackend, SearchFilter, OrderingFilter]
    filterset_fields = ['id', 'site', 'station', 'parameter', 'email']
    ordering_fields = ['id', 'parameter']

class EmailCreateViewSet(ModelViewSet):
    queryset = Email.objects.all()
    serializer_class = EmailSerializerCreate


