from rest_framework import serializers

from .models import Sites, Camera

class SiteSerializer(serializers.ModelSerializer):
    category = serializers.CharField(source='category.category', read_only=True)
    authority = serializers.CharField(source='authority.authority', read_only=True)
    state = serializers.CharField(source='state.state', read_only=True)
    city = serializers.CharField(source='city.city', read_only=True)

    class Meta:
        model = Sites
        fields = '__all__'

class SiteUpdateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Sites
        fields = ['category','authority','state', 'city', 'site_id', 'name','label','latitude',
        'longitude','configured_date', 'status']

class CameraSerializer(serializers.ModelSerializer):
    category = serializers.CharField(source='category.category', read_only=True)
    site = serializers.CharField(source='site.label', read_only=True)
    state = serializers.CharField(source='state.state', read_only=True)
    city = serializers.CharField(source='city.city', read_only=True)

    class Meta:
        model = Camera
        fields = '__all__'