from django_filters.rest_framework import DjangoFilterBackend
from rest_framework.filters import SearchFilter, OrderingFilter
from rest_framework.viewsets import ModelViewSet
from rest_framework import permissions
from rest_framework.response import Response
from oauth2_provider.contrib.rest_framework import TokenHasReadWriteScope

from .models import Sites, Camera
from .serializer import SiteSerializer, SiteUpdateSerializer, CameraSerializer

# Introduction viewset
class SiteViewSet(ModelViewSet):
    permission_classes = [permissions.IsAuthenticated, TokenHasReadWriteScope]
    queryset = Sites.objects.all().order_by('label')
    serializer_class = SiteSerializer
    filter_backends = [DjangoFilterBackend, SearchFilter, OrderingFilter]
    filterset_fields = ['id', 'label', 'category', 'state', 'city', 'authority', 'status']
    ordering_fields = ['id', 'label', 'name']

class SiteUpdateViewSet(ModelViewSet):
    queryset = Sites
    serializer_class = SiteUpdateSerializer
        
    def update(self, request, *args, **kwargs):
        partial = kwargs.pop('partial', True)
        instance = self.get_object()
        serializer = self.get_serializer(instance, data=request.data, partial=partial)
        serializer.is_valid(raise_exception=True)
        self.perform_update(serializer)
        return Response(serializer.data)
        

class CameraViewSet(ModelViewSet):
    permission_classes = [permissions.IsAuthenticated, TokenHasReadWriteScope]
    queryset = Camera.objects.all()
    serializer_class = CameraSerializer
    filter_backends = [DjangoFilterBackend, SearchFilter, OrderingFilter]
    filterset_fields = ['id', 'site', 'category', 'state', 'city', 'monitoring_type', 'status']
    ordering_fields = ['id']
    
