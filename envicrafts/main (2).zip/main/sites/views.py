from django.http.response import JsonResponse
from rest_framework.decorators import api_view
from .models import Sites, Camera
from setup.models import State, Category

import csv
@api_view(('GET',))
def ReadSiteStatusCSV(request):
    headers = request.headers
    if headers is not None:
        file = open("/home/ubuntu/project/main/automation/site_status.csv")
        csvreader = csv.reader(file)
        header = ["Date", "Active","Inactive","delay"]
        rows = []
        data = {}
        
        for row in csvreader:
            data = {header[i]: row[i] for i in range(len(row))}
            rows.append(data)
            
        file.close()

        response = {
                'status': "success",
                'data': rows
            }
    else: 
        response = {
            'status': "failed",
            'message': "Request has no header",
        }
    return JsonResponse(response, safe=False)

@api_view(('GET',))
def cameraSummary(request):
    headers = request.headers
    if headers is not None:
        if request.GET.get('site') and request.GET.get('category') and request.GET.get('status'):
            cameras_obj = Camera.objects.filter(site=request.GET.get('site'), 
            site__category=request.GET.get('category'), status=request.GET.get('status')).all()
        elif request.GET.get('site') and request.GET.get('category'):
            cameras_obj = Camera.objects.filter(site=request.GET.get('site'), 
            site__category=request.GET.get('category')).all()
        elif request.GET.get('site') and request.GET.get('status'):
            cameras_obj = Camera.objects.filter(site=request.GET.get('site'), 
            status=request.GET.get('status')).all()
        elif request.GET.get('category') and request.GET.get('status'):
            cameras_obj = Camera.objects.filter(site__category=request.GET.get('category'), 
            status=request.GET.get('status')).all()
        elif request.GET.get('site'):
            cameras_obj = Camera.objects.filter(site=request.GET.get('site')).all()
        elif request.GET.get('category'):
            cameras_obj = Camera.objects.filter(site__category=request.GET.get('category')).all()
        elif request.GET.get('status'):
            cameras_obj = Camera.objects.filter(status=request.GET.get('status')).all()
        elif request.GET.get('id'):
            cameras_obj = Camera.objects.filter(id=request.GET.get('id')).all()
        else:
            cameras_obj = Camera.objects.all()
        camera_data = [{'id': cam.id, 'site_id': cam.site.id, 'site_name': cam.site.name, 'site_label': cam.site.label, 'rtsp_path': cam.rtsp_path, 'ip': cam.ip_addr, 'username': cam.username, 'password': cam.password, 'channel': cam.channel,
        'site_category': cam.site.category.category, 'site_state': cam.site.state.state, 'site_city': cam.site.city.city, 'location': cam.location, 'status': cam.status, 'brand': cam.brand, 'model': cam.model, 'ptz': cam.ptz,
        'parameter': cam.parameter, 'monitoring_type':  cam.monitoring_type, 'latitude': cam.latitude, 'longitude': cam.longitude} 
        for cam in cameras_obj]
        response = {
                'status': "success",
                'data': camera_data
            }
    else: 
        response = {
            'status': "failed",
            'message': "Request has no header",
        }
    return JsonResponse(response, safe=False)

@api_view(('GET',))
def statusWiseSites(request):
    headers = request.headers
    if headers is not None:
        active_sites_count = Sites.objects.filter(status='Active').all().count()
        inactive_sites_count = Sites.objects.filter(status='Inactive').all().count()
        delayed_sites_count = Sites.objects.filter(status='Delayed').all().count()
        response = {
                'status': "success",
                'data': {
                    'active': active_sites_count,
                    'inactive': inactive_sites_count,
                    'delayed':delayed_sites_count
                }
            }
    else: 
        response = {
            'status': "failed",
            'message': "Request has no header",
        }
    return JsonResponse(response, safe=False)

@api_view(('GET',))
def stateWiseSites(request):
    headers = request.headers
    if headers is not None:
        states = State.objects.all()
        raw_data = {}
        for state in states:
            raw_data[state.state] = Sites.objects.filter(state=state.id).all().count()

        response = {
                'status': "success",
                'data': raw_data
            }
    else: 
        response = {
            'status': "failed",
            'message': "Request has no header",
        }
    return JsonResponse(response, safe=False)

@api_view(('GET',))
def categoryWiseSites(request):
    headers = request.headers
    if headers is not None:
        categories = Category.objects.all()
        raw_data = {}
        if request.GET.get('category'):
            if request.GET.get('status'):
                status = request.GET.get('status')
                raw_data[request.GET.get('category')] = Sites.objects.filter(category__category=request.GET.get('category'), status=status).all().count()
            else:
                raw_data[request.GET.get('category')] = Sites.objects.filter(category__category=request.GET.get('category')).all().count()
        else:
            for category in categories:
                if request.GET.get('status'):
                    status = request.GET.get('status')
                    raw_data[category.category] = Sites.objects.filter(category=category.id, status=status).all().count()
                else:
                    raw_data[category.category] = Sites.objects.filter(category=category.id).all().count()
        response = {
                'status': "success",
                'data': raw_data
            }
    else: 
        response = {
            'status': "failed",
            'message': "Request has no header",
        }
    return JsonResponse(response, safe=False)
