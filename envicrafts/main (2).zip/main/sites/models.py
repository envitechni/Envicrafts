from django.core.exceptions import ValidationError
from django.db import models
from django.utils import timezone

from setup.models import Category, State, City, Authority

# Create your models here.
class Sites(models.Model):
    STATUS_CHOICES = [
        ('Active', 'Active'),
        ('Inactive', 'Inactive'),
        ('Delayed', 'Delayed'),
    ]
    site_id = models.CharField(max_length=100, default="")
    name = models.CharField(max_length=100)
    label = models.CharField(max_length=10, unique=True)
    category = models.ForeignKey(Category, on_delete=models.CASCADE)
    state = models.ForeignKey(State, on_delete=models.CASCADE)
    city = models.ForeignKey(City, on_delete=models.CASCADE)
    address = models.CharField(max_length=200, blank=True)
    authority = models.ForeignKey(Authority, on_delete=models.CASCADE)
    latitude = models.CharField(max_length=100)
    longitude = models.CharField(max_length=100)
    configured_date = models.DateField(default=timezone.now)
    status = models.CharField(max_length=100, choices=STATUS_CHOICES)
    today_exceedance = models.IntegerField(default=0, null=True)

    def clean(self):
        if not self.label.isalpha():
            raise ValidationError({'label': "Only letters are allowed."})
            
    class Meta:
        verbose_name = "site"
        verbose_name_plural = "sites"
    
    def __str__(self):
        return str(self.label)

class Camera(models.Model):
    TYPE_CHOICES = [
        ('Ambient', 'Ambient'),
        ('Effluent', 'Effluent'),
        ('Emmission', 'Emmission'),
    ]
    site = models.ForeignKey(Sites, on_delete=models.CASCADE)
    rtsp_path = models.CharField(max_length=100)
    ip_addr = models.CharField(max_length=100, default=0)
    username = models.CharField(max_length=100, default=0)
    password = models.CharField(max_length=100, default=0)
    channel = models.IntegerField(default=1)
    brand = models.CharField(max_length=100, default=0)
    model = models.CharField(max_length=100, default=0)
    ptz = models.BooleanField(default=True)
    location = models.CharField(max_length=100, unique=True)
    state = models.ForeignKey(State, on_delete=models.CASCADE)
    city = models.ForeignKey(City, on_delete=models.CASCADE)
    latitude = models.CharField(max_length=100, default=0)
    longitude = models.CharField(max_length=100, default=0)
    parameter = models.CharField(max_length=100)
    category = models.ForeignKey(Category, on_delete=models.CASCADE)
    monitoring_type = models.CharField(max_length=100, choices=TYPE_CHOICES)
    status = models.BooleanField(default=False)