from django.contrib import admin

from .models import Sites, Camera

# Register your models here.
class SitesAdmin(admin.ModelAdmin):
    list_display = ('label', 'name', 'category', 'city', 'state', 'configured_date', 'status')
    list_filter = ('category', 'status',)

class CameraAdmin(admin.ModelAdmin):
    list_display = ('site', 'location', 'parameter', 'city', 'state', 'monitoring_type', 'status')
    list_filter = ('category', 'monitoring_type', 'status',)

admin.site.register(Sites, SitesAdmin)
admin.site.register(Camera, CameraAdmin)