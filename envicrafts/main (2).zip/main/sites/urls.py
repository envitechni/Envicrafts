from django.urls import path
from rest_framework import views
from .api import CameraViewSet, SiteViewSet, SiteUpdateViewSet
from . import views

urlpatterns = [
    path('', SiteViewSet.as_view({'get': 'list'})),
    path('site/patch/<int:pk>/', SiteUpdateViewSet.as_view({'patch': 'update'})),
    path('camera', views.cameraSummary, name="camera"),
    path('site-status/', views.ReadSiteStatusCSV, name="site-status"),
    path('site-statuswise-count/', views.statusWiseSites, name="site-statuswise-count/"),
    path('site-statewise-count/', views.stateWiseSites, name="site-statewise-count/"),
    path('site-categorywise-count/', views.categoryWiseSites, name="site-categorywise-count/"),
]
