from django.contrib import admin
from .models import Parameter,RealtimeValue

# Register your models here.
class ParameterAdmin(admin.ModelAdmin):
    list_display = ('parameter','unit','site','station','lower_min', 'lower_max','normal_min','normal_max','upper_min','upper_max',)
    list_filter = ('parameter','unit','site','station')
    
admin.site.register(Parameter, ParameterAdmin)

class RealtimeValueAdmin(admin.ModelAdmin):
    list_display = ('site','station','parameter','last_value','today_min','today_max','first_sync','last_sync')
    list_filter = ('site','station','parameter')

admin.site.register(RealtimeValue, RealtimeValueAdmin)