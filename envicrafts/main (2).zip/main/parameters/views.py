from django.http.response import JsonResponse
from rest_framework.decorators import api_view
from .models import Parameter, RealtimeValue

@api_view(('GET',))
def realtimeSites(request):
    headers = request.headers
    if headers is not None:
        if request.GET.get('category') and request.GET.get('status'):
            category = request.GET['category']
            status = request.GET['status']
            realtimes = RealtimeValue.objects.filter(site__category=category, site__status=status).all()
        elif request.GET.get('category'):
            category = request.GET['category']
            realtimes = RealtimeValue.objects.filter(site__category=category).all()
        elif request.GET.get('status'):
            status = request.GET['status']
            realtimes = RealtimeValue.objects.filter(site__status=status).all()
        elif request.GET.get('id'):
            realtimes = RealtimeValue.objects.filter(site=request.GET.get('id')).all()
        else:
            realtimes = RealtimeValue.objects.all()

        sites = {}
        for realtime in realtimes:
            site = []
            if realtime.site.label not in site:
                site = [realtime.site.id, realtime.site.site_id, realtime.site.name, realtime.site.label, realtime.site.category.category, 
                realtime.site.address, realtime.site.city.city, realtime.site.state.state, realtime.site.status, realtime.first_sync, 
                realtime.last_sync, realtime.site.today_exceedance, realtime.site.latitude, realtime.site.longitude, 
                ]
            sites[realtime.site.label] = site
        print(sites)
        response = {
            'status': "success",
            'data': sites,
        }
    else:
        response = {
            'status': "falied",
            'message': "Request has no headers",
        }
    return JsonResponse(response, safe=False)

@api_view(('GET',))
def realtimeValues(request):
    headers = request.headers
    if headers is not None:
        if request.GET.get('site') and request.GET.get('station') and request.GET.get('parameter'):
            realtimes_obj = RealtimeValue.objects.filter(site=request.GET.get('site'), station=request.GET.get('station'),
            parameter=request.GET.get('parameter')).all()
        elif request.GET.get('site') and request.GET.get('station'):
            realtimes_obj = RealtimeValue.objects.filter(site=request.GET.get('site'), station=request.GET.get('station')).all()
        elif request.GET.get('site') :
            realtimes_obj = RealtimeValue.objects.filter(site=request.GET.get('site')).all()
        elif request.GET.get('station') :
            realtimes_obj = RealtimeValue.objects.filter(station=request.GET.get('station')).all()
        elif request.GET.get('id') :
            realtimes_obj = RealtimeValue.objects.filter(id=request.GET.get('id')).all()
        else:
            realtimes_obj = RealtimeValue.objects.all()
            
        realtime_data = [[realtime.site.id, realtime.site.name, realtime.site.label, realtime.site.status, realtime.station.station, realtime.station.monitoring_type,
        realtime.parameter.parameter, realtime.parameter.unit, realtime.parameter.normal_min, realtime.parameter.normal_max, realtime.first_sync, realtime.last_sync, realtime.last_value, realtime.today_min, 
        realtime.today_max, realtime.id] for realtime in realtimes_obj]
        response = realtime_data
    else:
        response = {
            'status': "falied",
            'message': "Request has no headers",
        }
    return JsonResponse(response, safe=False)

@api_view(('GET',))
def parameters(request):
    headers = request.headers
    if headers is not None:
        if request.GET.get('site') and request.GET.get('station'):
            parameters_obj = Parameter.objects.filter(site=request.GET.get('site'), station=request.GET.get('station'),).all()
        elif request.GET.get('site'):
            parameters_obj = Parameter.objects.filter(site=request.GET.get('site'),).all()
        elif request.GET.get('station'):
            parameters_obj = Parameter.objects.filter(station=request.GET.get('station')).all()
        elif request.GET.get('station_name') and request.GET.get('parameter'):
            parameters_obj = Parameter.objects.filter(station__station=request.GET.get('station_name'), 
            parameter=request.GET.get('parameter')).all()
        elif request.GET.get('station_name'):
            parameters_obj = Parameter.objects.filter(station__station=request.GET.get('station_name')).all()
        else:
            parameters_obj = Parameter.objects.all()
            
        parameter_data = [{'id': parameter.id, 'site_id': parameter.site.id, 'site_name': parameter.site.name, 
        'site_label': parameter.site.label, 'station_id': parameter.station.id, 'station': parameter.station.station, 'parameter': parameter.parameter, 
        'unit': parameter.unit, 'standard_limit': parameter.standard_limit, 'lower': parameter.lower_min, 'upper': parameter.upper_max,
        'normal_min': parameter.normal_min, 
        'normal_max': parameter.normal_max, 'address': parameter.station.device_address, 'span': parameter.span_callibration, 
        'zero': parameter.zero_callibration} 
        for parameter in parameters_obj]
        response = parameter_data
    else: 
        response = {
            'status': "failed",
            'message': "Request has no header",
        }
    return JsonResponse(response, safe=False)

@api_view(('GET',))
def parametersCount(request):
    headers = request.headers
    if headers is not None:
        if request.GET.get('site') and request.GET.get('station'):
            parameters_obj = Parameter.objects.filter(site=request.GET.get('site'), station=request.GET.get('station')).all().count()
        elif request.GET.get('site') :
            parameters_obj = Parameter.objects.filter(site=request.GET.get('site')).all().count()
        elif request.GET.get('station') :
            parameters_obj = Parameter.objects.filter(station=request.GET.get('station')).all().count()
        else:
            parameters_obj = Parameter.objects.all().count()
        
        response = {
            'status': "success",
            'data': parameters_obj,
        }
    else: 
        response = {
            'status': "failed",
            'message': "Request has no header",
        }
    return JsonResponse(response, safe=False)

@api_view(('GET',))
def calibrationParameters(request):
    headers = request.headers
    if headers is not None:
        if request.GET.get('site') and request.GET.get('station'):
            parameters_obj = Parameter.objects.filter(site=request.GET.get('site'), station=request.GET.get('station'), span_callibration=True, zero_callibration=True).all()
        elif request.GET.get('site') :
            parameters_obj = Parameter.objects.filter(site=request.GET.get('site'), span_callibration=True, zero_callibration=True).all()
        elif request.GET.get('station') :
            parameters_obj = Parameter.objects.filter(station=request.GET.get('station')).all()
        elif request.GET.get('station_name'):
            parameters_obj = Parameter.objects.filter(station__station=request.GET.get('station_name'), span_callibration=True, zero_callibration=True).all()
        elif request.GET.get('id'):
            parameters_obj = Parameter.objects.filter(id=request.GET.get('id'), span_callibration=True, zero_callibration=True).all()
        else:
            parameters_obj = Parameter.objects.filter(span_callibration=True, zero_callibration=True).all()
            
        parameter_data = [{'id': parameter.id, 'site_id': parameter.site.id, 'site_name': parameter.site.name, 
        'site_label': parameter.site.label, 'station': parameter.station.station, 'parameter': parameter.parameter, 
        'unit': parameter.unit, 'standard_limit': parameter.standard_limit, 'normal_min': parameter.normal_min, 
        'normal_max': parameter.normal_max, 'address': parameter.station.device_address, 'span': parameter.span_callibration, 
        'zero': parameter.zero_callibration} 
        for parameter in parameters_obj]
        response = parameter_data
    else: 
        response = {
            'status': "failed",
            'message': "Request has no header",
        }
    return JsonResponse(response, safe=False)
