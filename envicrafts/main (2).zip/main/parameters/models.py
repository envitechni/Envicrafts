from django.db import models
from sites.models import Sites
from stations.models import Stations
from django.db.models.signals import post_save

# Create your models here.
class Parameter(models.Model):
    parameter = models.CharField(max_length=100)
    unit = models.CharField(max_length=100)
    site = models.ForeignKey(Sites, on_delete=models.CASCADE)
    station = models.ForeignKey(Stations, on_delete=models.CASCADE)
    standard_limit = models.BooleanField(default=False)
    lower_min = models.FloatField(null=False,blank=False)
    lower_max = models.FloatField(null=False,blank=False)
    normal_min = models.FloatField(null=False,blank=False)
    normal_max = models.FloatField(null=False,blank=False)
    upper_min = models.FloatField(null=False,blank=False)
    upper_max = models.FloatField(null=False,blank=False)
    span_callibration = models.BooleanField(default=False)
    zero_callibration = models.BooleanField(default=False)
    
    class Meta:
       verbose_name = "Parameter"
       verbose_name_plural = "Parameters"
    
    def __str__(self):
        return str(self.parameter)

def realtimevalue_post_save(sender, instance, created, *args, **kwargs):
    if created:
        realtimevalue = RealtimeValue.objects.create(site=instance.site,station=instance.station,parameter=instance)
        realtimevalue.save()

post_save.connect(realtimevalue_post_save, sender=Parameter)

class RealtimeValue(models.Model):
    site = models.ForeignKey(Sites, on_delete=models.CASCADE)
    station = models.ForeignKey(Stations, on_delete=models.CASCADE)
    parameter = models.ForeignKey(Parameter, on_delete=models.CASCADE)
    last_value = models.FloatField(default=None,null=True)
    today_min = models.FloatField(default=None,null=True)
    today_max = models.FloatField(default=None,null=True)
    first_sync = models.DateTimeField(default=None,null=True)
    last_sync = models.DateTimeField(default=None,null=True)
