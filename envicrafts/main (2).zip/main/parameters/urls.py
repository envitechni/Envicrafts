from django.urls import path
from rest_framework import views
from . import views

urlpatterns = [
    path('', views.parameters ,name="paramters"),
    path('total-parameters', views.parametersCount ,name="total-parameters"),
    path('calibration', views.calibrationParameters ,name="calibration-parameters"),
    path('realtime-values/', views.realtimeValues, name="realtime-values"),
    path('realtime-sites/', views.realtimeSites, name="realtime-sites"),
]
