from django.http.response import JsonResponse
from django.http import JsonResponse
from notifications.signals import notify
from rest_framework.decorators import api_view
from user.models import User
from sites.models import Sites
from notifications.models import Notification

# Create your views here.

@api_view(('POST',))
def sendNotification(request):
    token = request.headers
    if token is not None:
        current_user = User.objects.get(username=request.user)
        site = Sites.objects.all()
        sender = request.user
        data = request.data
        if request.user.is_staff and current_user.role == 'Admin':
            selected_site = data['site']
            type = data['type']
            level = data['level']
            title  = data['title']
            description  = data['description']

            recipient = ""
            if selected_site == "all" and type == "all":
                recipient = User.objects.filter(is_superuser=False).all()
            elif selected_site != "all" and type == "all":
                recipient = User.objects.filter(is_staff=False, site_id=selected_site).all()
            elif selected_site == "all" and type != "all":
                recipient = User.objects.filter(is_superuser=False, role=type).all()
            elif selected_site != "all" and type != "all":
                recipient = User.objects.filter(is_staff=False, site_id=selected_site, role=type).all()
            else:
                recipient = ""

            try:
                notify.send(sender=sender, recipient=recipient, verb=title, description=description, level=level)
                message = {
                    'status': "success",
                    'message': "Notification send!"
                }
            except:
                message = {
                    'status': "Failed",
                    'message': "Notification can not send!"
                }
        else:
            message = {
                'status': "Failed",
                'message': "You are not authorised to send notifications!"
            }
    else:
        message = {
            'status': "Failed",
            'message': "Request has no headers"
        }
    return JsonResponse(message, safe=False)

@api_view(('DELETE',))
def deleteNotification(request, pk):
    token = request.headers
    if token is not None:
        try:
            # id = request.GET['id']
            Notification.objects.filter(id=pk).delete()
            message = {
                'status': "success",
                'message': "Notification Deleted!"
            }
        except:
            message = {
                'status': "Failed",
                'message': "Notification can't delete! Try again."
            }
    else:
        message = {
            'status': "Failed",
            'message': "Request has no headers"
        }
    return JsonResponse(message, safe=False)
