from rest_framework import serializers
from notifications.models import Notification

class NotificationsSerializer(serializers.ModelSerializer):
    class Meta:
        model = Notification
        fields = ['id', 'level', 'unread', 'verb', 'description', 'timestamp', 'recipient_id', 'deleted', 'emailed']

class SendNotificationSerializer(serializers.ModelSerializer):
    class Meta:
        model = Notification
        fields =  '__all__'

class UpdateNotificationSerializer(serializers.ModelSerializer):
    class Meta:
        model = Notification
        fields =  '__all__'
