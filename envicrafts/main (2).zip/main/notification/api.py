from django_filters.rest_framework import DjangoFilterBackend
from rest_framework.filters import SearchFilter, OrderingFilter
from rest_framework.viewsets import ModelViewSet
from notifications.models import Notification
from rest_framework.response import Response
from .serializer import NotificationsSerializer, SendNotificationSerializer, UpdateNotificationSerializer
from rest_framework.pagination import PageNumberPagination

# Introduction viewset
class Pagination(PageNumberPagination):
    page_size = 50
    page_size_query_param = 'page_size'
    max_page_size = 100

class NotificationsViewSet(ModelViewSet):
    queryset = Notification.objects.all()
    serializer_class = NotificationsSerializer
    filter_backends = [DjangoFilterBackend, SearchFilter, OrderingFilter]
    pagination_class = Pagination
    search_field = ['recipient_id']
    filterset_fields = ['id', 'level', 'unread', 'verb', 'description', 'timestamp', 'recipient_id', 'deleted', 'emailed']
    ordering_fields = ['id', 'level', 'unread', 'verb', 'description', 'timestamp', 'recipient_id', 'deleted', 'emailed']        

class SendNotificationViewSet(ModelViewSet):
    queryset = Notification.objects.all()
    serializer_class = SendNotificationSerializer

class UpdateNotificationViewSet(ModelViewSet):
    queryset = Notification
    serializer_class = UpdateNotificationSerializer
        
    def update(self, request, *args, **kwargs):
        partial = kwargs.pop('partial', True)
        instance = self.get_object()
        serializer = self.get_serializer(instance, data=request.data, partial=partial)
        serializer.is_valid(raise_exception=True)
        self.perform_update(serializer)
        return Response(serializer.data)
