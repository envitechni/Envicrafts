from django.urls import path
from . import views
from .api import UpdateNotificationViewSet, NotificationsViewSet

urlpatterns = [
    path('send/', views.sendNotification, name="notification-send"),
    path('list', NotificationsViewSet.as_view({'get': 'list'})),
    path('patch/<int:pk>/', UpdateNotificationViewSet.as_view({'patch': 'update'})),
    path('destroy/<int:pk>/', views.deleteNotification, name="notification-delete"),
]