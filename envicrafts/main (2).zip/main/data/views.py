from django.http.response import JsonResponse
from data.models import DataModel
from parameters.models import Parameter
from rest_framework.decorators import api_view

from django.db.models.functions import ExtractHour, ExtractMinute, Cast, TruncMinute
from django.db.models import Case, When, Value, CharField, DateTimeField

import statistics as stat

def dataWithDateTime(fromDate, toDate, site, station, parameter, interval):
    data_obj = DataModel.objects.annotate(
        time_data=((ExtractHour("dateTime") * 60) + ExtractMinute("dateTime")) % interval,
    ).annotate(
        datetime=Cast(
            TruncMinute('dateTime', DateTimeField()), CharField()
        )
    ).filter(
        dateTime__date__range=[fromDate, toDate], site=site, station=station, parameter=parameter, time_data=0
    ).all()
    data = {}
    for d in data_obj:
        data[d.datetime] = d.values
    return data

def dataStat(fromDate, toDate, site, station, parameter, interval):
    data_obj = DataModel.objects.annotate(
        time_data=((ExtractHour("dateTime") * 60) + ExtractMinute("dateTime")) % interval,
    ).filter(
        dateTime__date__range=[fromDate, toDate], site=site, station=station, parameter=parameter, time_data=0
    ).values_list('values', flat=True)
    values = data_obj
    
    data = []
    try:
        average = round(stat.mean(values), 2)
    except:
        average = "NA"
    try:
        min_value = round(min(values), 2)
    except:
        min_value = "NA"
    try:
        max_value = round(max(values), 2)
    except:
        max_value = "NA"
    try:
        medain_value = round(stat.median(values), 2)
    except:
        medain_value = "NA"
    try:
        mode_value = round(stat.mode(values), 2)
    except:
        mode_value = "NA"
    try:
        deviation = round(stat.stdev(values), 2)
    except:
        deviation = "NA"

    data = [average, min_value, max_value, medain_value, mode_value, deviation]
    return data

def exceedData(fromDate, toDate, site, station, parameter, interval):
    parameter_obj = Parameter.objects.get(site__label=site, station__station=station, parameter=parameter)
    normal_min = parameter_obj.normal_min
    normal_max = parameter_obj.normal_max
    normal_max = str(normal_max)
    data_obj = DataModel.objects.annotate(
        time_data=((ExtractHour("dateTime") * 60) + ExtractMinute("dateTime")) % interval,
    ).annotate(
        data_code=Case(
            When(values__lt = normal_min, then=Value("E")),
            When(values__gt = normal_max, then=Value("E")),
            default=Value('N'),
        )
    ).annotate(
        datetime=Cast(
            TruncMinute('dateTime', DateTimeField()), CharField()
        )
    ).filter(
        dateTime__date__range=[fromDate, toDate], site=site, station=station, parameter=parameter, time_data=0
    )
    data = {}
    for d in data_obj:
        data[d.datetime] = [d.values, d.data_code]
    return data

def percentileData(fromDate, toDate, site, station, parameter, value):
    less = DataModel.objects.filter(
        dateTime__date__range=[fromDate, toDate], site=site, station=station, parameter=parameter, values__lt=value
    ).count()
    greater = DataModel.objects.filter(
        dateTime__date__range=[fromDate, toDate], site=site, station=station, parameter=parameter, values__gt=value
    ).count()
    equal = DataModel.objects.filter(
        dateTime__date__range=[fromDate, toDate], site=site, station=station, parameter=parameter, values=value
    ).count()
    data = ['Less Than', 'Greater Than', 'Equal'], [less, greater, equal]
    return data

@api_view(('GET',))
def average(request):
    token = request.headers
    if token is not None:
        fromDate = request.GET['from']
        toDate = request.GET['to']
        site = request.GET['site']
        station = request.GET['station']
        parameters = request.GET.getlist('parameters')
        interval = request.GET.getlist('interval')
        raw_data = {}
        for parameter in parameters:
            raw_data[parameter] = dataWithDateTime(fromDate, toDate, site, station, parameter, interval)
        message = raw_data
    else:
        message = {
            'status': "success",
            'message': "Request has no headers"
        }
    return JsonResponse(message, safe=False)

@api_view(('GET',))
def exceedance(request):
    token = request.headers
    if token is not None:
        fromDate = request.GET['from']
        toDate = request.GET['to']
        site = request.GET['site']
        station = request.GET['station']
        parameters = request.GET['parameters']
        interval = 15
        raw_data = {}
        raw_data[parameters] = exceedData(fromDate, toDate, site, station, parameters, interval)
        message = raw_data
    else:
        message = {
            'status': "success",
            'message': "Request has no headers"
        }
    return JsonResponse(message, safe=False)

@api_view(('GET',))
def percentile(request):
    token = request.headers
    if token is not None:
        fromDate = request.GET['from']
        toDate = request.GET['to']
        site = request.GET['site']
        station = request.GET['station']
        parameters = request.GET['parameters']
        value = request.GET['value']
        raw_data = []
        raw_data = percentileData(fromDate, toDate, site, station, parameters, value)
        message = raw_data
    else:
        message = {
            'status': "success",
            'message': "Request has no headers"
        }
    return JsonResponse(message, safe=False)

@api_view(('GET',))
def statistics(request):
    token = request.headers
    if token is not None:
        fromDate = request.GET['from']
        toDate = request.GET['to']
        site = request.GET['site']
        station = request.GET['station']
        parameters = request.GET.getlist('parameters')
        interval = request.GET.getlist('interval')

        raw_data = {}
        for parameter in parameters:
            raw_data[parameter] = dataStat(fromDate, toDate, site, station, parameter, interval)

        message = raw_data,
    else:
        message = {
            'status': "success",
            'message': "Request has no headers"
        }
    return JsonResponse(message, safe=False)
