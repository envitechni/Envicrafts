from django.db import models

# Create your models here.
class DataModel(models.Model):
    dateTime   = models.DateTimeField(null=False, blank=False)
    site       = models.CharField(max_length=100, null=False)
    station    = models.CharField(max_length=100, null=False)
    parameter  = models.CharField(max_length=100, null=False)
    values     = models.FloatField(max_length=100, null=False)
    
    class Meta:
        verbose_name_plural = "Data"