from django.urls import path
from . import views

urlpatterns = [
    path('average/', views.average, name="average"),
    path('exceedance/', views.exceedance, name="exceedance"),
    path('percentile/', views.percentile, name="percentile"),
    path('statistics/', views.statistics, name="statistics"),
]