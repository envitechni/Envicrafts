from django.contrib import admin
from .models import DataModel

# Register your models here.
class DataAdmin(admin.ModelAdmin):
    list_display = ('dateTime', 'site', 'station', 'parameter', 'values')
    list_filter = ('site', 'station', 'parameter')

admin.site.register(DataModel, DataAdmin)