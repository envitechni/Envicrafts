from django.http.response import JsonResponse
from rest_framework.decorators import api_view
from .models import AuditLogs

@api_view(('GET',))
def logs(request):
    headers = request.headers
    if headers is not None:
        if request.GET.get('username') and request.GET.get('action'):
            logs_obj = AuditLogs.objects.filter(username=request.GET.get('username'), action_type=request.GET.get('action')).all()
        elif request.GET.get('username'):
            logs_obj = AuditLogs.objects.filter(username=request.GET.get('username')).all()
        elif request.GET.get('action'):
            logs_obj = AuditLogs.objects.filter(action_type=request.GET.get('action')).all()
        else:
            logs_obj = AuditLogs.objects.all()

        logs_data = [{'timestamp': log.timestamp, 'user': log.username, 'action': log.action_type, 'description': log.action} 
        for log in logs_obj]
        response = {
                'status': "success",
                'data': logs_data
            }
    else: 
        response = {
            'status': "failed",
            'message': "Request has no header",
        }
    return JsonResponse(response, safe=False)