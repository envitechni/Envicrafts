from django.contrib import admin
from .models import AuditLogs

# Register your models here.
class AuditLogsAdmin(admin.ModelAdmin):
    list_display = ('timestamp','username','action_type','action','ip_address',)
    list_filter = ('username','action_type')

admin.site.register(AuditLogs, AuditLogsAdmin)