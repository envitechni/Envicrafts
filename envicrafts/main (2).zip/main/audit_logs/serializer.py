from rest_framework import serializers

from .models import AuditLogs

class AuditLogsSerializer(serializers.ModelSerializer):
    class Meta:
        model = AuditLogs
        fields = ['timestamp','username','action_type','action','ip_address',]
