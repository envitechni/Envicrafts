from django.urls import path
from rest_framework import views
from .api import AuditLogsViewSet
from . import views

urlpatterns = [
    path('', views.logs,name='auditlogs'),
    path('create/', AuditLogsViewSet.as_view({'post': 'create'})),
]