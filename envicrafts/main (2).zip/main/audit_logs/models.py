from django.db import models

# Create your models here.
# Time, Username, Action type, Action, IP address
class AuditLogs(models.Model):
    timestamp = models.DateTimeField()
    username = models.CharField(max_length=20)
    action_type = models.CharField(max_length=20)
    action = models.CharField(max_length=100)
    ip_address = models.CharField(max_length=50)
    
    class Meta:
        verbose_name = "Audit Log"
        verbose_name_plural = "Audit Logs"
    
    def __str__(self):
        return str(self.username)