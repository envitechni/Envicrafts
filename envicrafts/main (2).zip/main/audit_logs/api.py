from django_filters.rest_framework import DjangoFilterBackend
from rest_framework.filters import SearchFilter, OrderingFilter
from rest_framework.viewsets import ModelViewSet
from .models import AuditLogs
from .serializer import AuditLogsSerializer

# Introduction viewset
class AuditLogsViewSet(ModelViewSet):
    queryset = AuditLogs.objects.all()
    serializer_class = AuditLogsSerializer
    filter_backends = [DjangoFilterBackend, SearchFilter, OrderingFilter]
    filterset_fields = ['timestamp','username','action_type','action','ip_address']
    ordering_fields = ['timestamp', 'username','action_type','action','ip_address']
