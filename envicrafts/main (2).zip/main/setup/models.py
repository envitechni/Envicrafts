from django.db import models

# Create your models here.
class Authority(models.Model):
    authority = models.CharField(max_length=100, unique=True)

    class Meta:
        verbose_name_plural = "authorities"

    def __str__(self):
        return str(self.authority)

class Category(models.Model):
    category = models.CharField(max_length=100, unique=True)

    class Meta:
        verbose_name_plural = "categories"

    def __str__(self):
        return str(self.category)

class State(models.Model):
    state = models.CharField(max_length=100, unique=True)
    latitude = models.CharField(max_length=100)
    longitude = models.CharField(max_length=100)

    def __str__(self):
        return str(self.state)

class City(models.Model):
    city = models.CharField(max_length=100, unique=True)
    state = models.ForeignKey(State, on_delete=models.CASCADE)
    latitude = models.CharField(max_length=100)
    longitude = models.CharField(max_length=100)

    class Meta:
        verbose_name_plural = "cities"

    def __str__(self):
        return str(self.city)