from django.contrib import admin

from .models import Authority, Category, State, City
# Register your models here.

class AuthorityAdmin(admin.ModelAdmin):
    list_display = ('authority',)

class CategoryAdmin(admin.ModelAdmin):
    list_display = ('category',)

class StateAdmin(admin.ModelAdmin):
    list_display = ('state', 'latitude', 'longitude')

class CityAdmin(admin.ModelAdmin):
    list_display = ('city', 'state', 'latitude', 'longitude')

admin.site.register(Authority, AuthorityAdmin)
admin.site.register(Category, CategoryAdmin)
admin.site.register(State, StateAdmin)
admin.site.register(City, CityAdmin)