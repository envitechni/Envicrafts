from rest_framework import serializers
from .models import Authority, Category, City, State

class AuthoritySerializer(serializers.ModelSerializer):
    class Meta:
        model = Authority
        fields = ['id', 'authority']

class CategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = Category
        fields = ['id', 'category']

class CitySerializer(serializers.ModelSerializer):
    state = serializers.CharField(source='state.state', read_only=True)
    class Meta:
        model = City
        fields = ['id', 'city', 'state', 'latitude', 'longitude']

class StateSerializer(serializers.ModelSerializer):
    class Meta:
        model = State
        fields = ['id', 'state', 'latitude', 'longitude']