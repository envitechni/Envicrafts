from django.urls import path
from .api import AuthorityViewSet, CategoryViewSet, CityViewSet, StateViewSet

urlpatterns = [
    path('authority/', AuthorityViewSet.as_view({'get': 'list'})),
    path('category/', CategoryViewSet.as_view({'get': 'list'})),
    path('city/', CityViewSet.as_view({'get': 'list'})),
    path('state/', StateViewSet.as_view({'get': 'list'})),  
]