from django.contrib import admin
from .models import CalibrationLogs

# Register your models here.
class CalibrationLogsAdmin(admin.ModelAdmin):
    list_display = ('site', 'station', 'parameter', 'type_of', 'calibrator', 'start_time')
    list_filter = ('site', 'station', 'type_of')

admin.site.register(CalibrationLogs, CalibrationLogsAdmin)