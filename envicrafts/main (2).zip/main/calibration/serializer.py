from rest_framework import serializers

from .models import CalibrationLogs

class CalibrationSerializer(serializers.ModelSerializer):
    class Meta:
        model = CalibrationLogs
        fields = ['site', 'station', 'parameter', 'type_of', 'calibrator', 'start_time']
