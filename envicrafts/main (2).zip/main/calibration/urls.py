from django.urls import path
from rest_framework import views
from .api import CalibrationViewSet
from . import views

urlpatterns = [
    path('logs/', views.logs, name='calibration-logs'),
    path('activate-calibration/',views.activateCalibration, name="activate-calibration"),
    path('create/', CalibrationViewSet.as_view({'post': 'create'})),
]
