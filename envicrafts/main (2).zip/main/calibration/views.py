from django.http.response import Http404
from requests_http_signature import HTTPSignatureAuth
from base64 import b64decode
from .models import CalibrationLogs
from django.http.response import JsonResponse
from rest_framework.decorators import api_view

import requests
import datetime

@api_view(('GET',))
def logs(request):
    headers = request.headers
    if headers is not None:
        if request.GET.get('site'):
            obj = CalibrationLogs.objects.filter(site=request.GET.get('site')).all()
        else:
            obj = CalibrationLogs.objects.all()
        log_data = [{'site_id': calibration.site.id, 'site_name': calibration.site.name, 'site_label': calibration.site.label, 
        'station': calibration.station.station, 'parameter': calibration.parameter.parameter, 'type': calibration.type_of,
        'calibrator': calibration.calibrator, 'start_time': calibration.start_time}
        for calibration in obj]
        response = log_data
    else: 
        response = {
            'status': "failed",
            'message': "Request has no header",
        }
    return JsonResponse(response, safe=False)

def activateCalibration(request):
    headers = request.session['headers']
    ip = request.session['ip']

    id = request.GET['id']
    type = request.GET['type']
    callibration_url = ip+"/calibration/callibrate-detail/"
    callibration_params = {
        'id': id,
    }
    devices = requests.request('GET', callibration_url, headers=headers, params=callibration_params)
    key_id =  'BOYSAV6M7AF5OH6ACMH5'
    key_secret_id = 'YuSAjd0Z8uWKUJogFZkJTFTCI9wKd3H/fyRBnBgt'
    api_key = 'MTYyQUVFRTEtOUI4Ny00OUNBLUJCMkItRjU5QkJDMjY0RTE4'
    
    host = 'api.remot3.it'
    url_path = '/apv/v27/device/connect'
    content_type_header = 'application/json'
    headers = {
        'host': host,
        'content_type_header': content_type_header,
        'content_length_header': content_type_header,
        'DeveloperKey': api_key,
    }
    auth = HTTPSignatureAuth(algorithm="hmac-sha256", key=b64decode(key_secret_id),key_id=key_id)
    body = {
        "deviceaddress": devices.json()[0]['device_address'],
        "wait": "true",
        "hostip": "0.0.0.0",
    }
    response = requests.post('https://' + host + url_path, auth=auth, headers=headers, json=body)
    if response.status_code == 200:
        if response.json()['status'] == "true":
            ip = response.json()["connection"]["proxy"]
            if type == "Zero":
                relay_address = requests.get(ip + "/callibration?type=Zero")
                message = {
                    'status': "success",
                    'message': type + " Callibration is activated"
                }
                CalibrationLogs.objects.create(site=devices.json()[0]['site'], station=devices.json()[0]['station'], type_of=type,
                parameter=devices.json()[0]['parameter'], calibrator=request.user, start_time=datetime.datetime.now())
            elif type == "Span":
                relay_address = requests.get(ip + "/callibration?type=Span")
                message = {
                    'status': "success",
                    'message': type + " Callibration is activated"
                }
                CalibrationLogs.objects.create(site=devices.json()[0]['site'], station=devices.json()[0]['station'], type_of=type,
                parameter=devices.json()[0]['parameter'], calibrator=request.user, start_time=datetime.datetime.now())
            else:
                raise Http404     
        else:
            message = {
                'status': "success",
                'message': "Device could not connect"
            }
    else:
        message = {
            'status': "success",
            'message': "Device not available"
        }

    return JsonResponse(message, safe=False)