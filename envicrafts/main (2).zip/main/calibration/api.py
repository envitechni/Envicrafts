from django_filters.rest_framework import DjangoFilterBackend
from rest_framework.filters import SearchFilter, OrderingFilter
from rest_framework.viewsets import ModelViewSet

from .models import CalibrationLogs
from .serializer import CalibrationSerializer

# Introduction viewset
class CalibrationViewSet(ModelViewSet):
    queryset = CalibrationLogs.objects.all()
    serializer_class = CalibrationSerializer
    filter_backends = [DjangoFilterBackend, SearchFilter, OrderingFilter]
    filterset_fields = ['site', 'station', 'parameter', 'type_of', 'calibrator']
    ordering_fields = ['id', 'site', 'station', 'parameter']