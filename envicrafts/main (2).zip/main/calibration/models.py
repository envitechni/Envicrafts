from django.db import models
from sites.models import Sites
from stations.models import Stations
from parameters.models import Parameter

# Create your models here.
class CalibrationLogs(models.Model):
    site = models.ForeignKey(Sites, on_delete=models.CASCADE)
    station = models.ForeignKey(Stations, on_delete=models.CASCADE)
    parameter = models.ForeignKey(Parameter, on_delete=models.CASCADE)
    type_of = models.CharField(max_length=100,null=False,blank=False) 
    calibrator = models.CharField(max_length=100,null=False,blank=False)
    start_time = models.DateTimeField()

    class Meta:
        verbose_name = "Calibration Log"
        verbose_name_plural = "calibration Logs"