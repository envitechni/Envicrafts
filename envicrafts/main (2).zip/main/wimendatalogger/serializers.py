from dataclasses import field
from rest_framework import serializers
from .models import Wimendetails

class Wimenserializer(serializers.ModelSerializer):
    class Meta:
        model = Wimendetails
        fields = ['serial_number','date','site_name','device_number','network_protocol','mobile','IMEI_No','configuration','wiman_model','sno','mfg','mqtt','username','password','site_category']
        

class Wimenserializerlist(serializers.ModelSerializer):
    class Meta:
        model = Wimendetails
        fields = '__all__'
        