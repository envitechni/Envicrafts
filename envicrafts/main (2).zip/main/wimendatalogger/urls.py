from django.urls import path
from .api import WimenApiviewset,WimenApiviewsetlist
from . import views

urlpatterns = [

    path('wiman/create/',WimenApiviewset.as_view({'post':'create'})),
    path('wiman/list/',WimenApiviewsetlist.as_view({'get':'list'})),

]