from django.apps import AppConfig


class WimendataloggerConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'wimendatalogger'
