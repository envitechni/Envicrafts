from django.contrib import admin
from . models import Wimendetails

# Register your models here.

class wimenadmin(admin.ModelAdmin):
    list_display = ('serial_number','date',' site_name','device_number','network_protocol','mobile','IMEI_No','configuration','wiman_model','sno','mfg','mqtt','username','password','site_category')

admin.site.register(Wimendetails)    