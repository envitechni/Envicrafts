from ast import Set
from django.db import models

# Create your models here.

Network=(
    ('4g','4g'),
    ('Lan','Lan'),
    ('4g + Lan','4g + Lan'),
    ('wifi','wifi'),
)

Configuration=(
    ('RS485','RS485'),
    ('RELAY','RELAY'),
    ('4-20 mA','4220 mA'),
    ('Analog','Analog'),
    ('Digital','Digital'),
)

monitoring_type_choises = (       
    ("ambient", "Ambient"),            
    ("effluent", "Effluent"),           
    ("emission", "Emission"),
)

Wimen_Model=(
    ('WT400M','WT400M'),
    ('WT420C','WT420C'),
    ('WT905M','WT905M'),
    ('WT705M','WT705M'),
    ('WT 30i','WT 30i'),
    ('WT 60i','WT 60i'),
)

class Wimendetails(models.Model):
    serial_number = models.CharField(max_length=50)
    date = models.DateField()
    site_name = models.CharField(max_length=50) 
    device_number = models.CharField(max_length=50)
    network_protocol = models.CharField(max_length=50,choices=Network)
    mobile = models.CharField(max_length=20)
    IMEI_No = models.CharField(max_length=50)
    configuration = models.CharField(max_length=50)
    wiman_model = models.CharField(max_length=50,choices=Wimen_Model)
    sno = models.CharField(max_length=50)
    mfg = models.CharField(max_length=50)
    mqtt = models.CharField(max_length=50)
    username = models.CharField(max_length=40)
    password = models.CharField(max_length=40)
    site_category = models.CharField(max_length=50,choices=monitoring_type_choises)


    def __str__(self):
        return str(self.wiman_model)
    