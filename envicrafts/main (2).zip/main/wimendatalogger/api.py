from rest_framework.viewsets import ModelViewSet
from .models import Wimendetails
from .serializers import Wimenserializer,Wimenserializerlist
from rest_framework.filters import SearchFilter, OrderingFilter
from django_filters.rest_framework import DjangoFilterBackend




class WimenApiviewset(ModelViewSet):
    queryset = Wimendetails.objects.all()
    serializer_class = Wimenserializer 
    
    filter_backends = [DjangoFilterBackend, SearchFilter, OrderingFilter]
    filterset_fields = ['id','serial_number','site_name','device_number','wiman_model',]
    ordering_fields = ['id','serial_number','site_name','device_number']


class WimenApiviewsetlist(ModelViewSet):
    queryset = Wimendetails.objects.all()
    serializer_class = Wimenserializerlist